#!/usr/bin/python3 -I
"""Only the installed, root-owned helper is eligible for real disk operations."""
import json,sys,os
from pathlib import Path
def trust_before_import(path):
    resolved=Path(path).resolve(strict=True)
    for part in [resolved,*resolved.parents]:
        info=part.stat()
        if info.st_uid!=0 or info.st_mode&0o022:raise PermissionError('Installed helper must be root-owned and protected: '+str(part))
    return resolved
if __name__=='__main__':
    try:
        if os.geteuid()!=0:raise PermissionError('Administrator privileges are required')
        root=trust_before_import(__file__).parent
        for module in (root/'dango').glob('*.py'):trust_before_import(module)
        sys.path.insert(0,str(root))
        from dango.engine import trusted,execute
        from dango.model import load_profile
        profile=load_profile(trusted('/etc/dango-loader/installer.json'))
        raw=sys.stdin.buffer.read(32769)
        if len(raw)>32768:raise ValueError('Request is too large')
        data=json.loads(raw)
        if data.get('action')=='scan':
            from dango.storage import discover
            print(json.dumps({'inventory':discover()}),flush=True)
        elif data.get('action')=='limits':
            from dango.storage import discover,eligible_partitions,ntfs_limits
            row=next((r for r in eligible_partitions(discover()) if r['path']==data.get('device') and r.get('fstype')=='ntfs'),None)
            if not row:raise ValueError('Choose an unmounted NTFS partition')
            print(json.dumps({'minimum':ntfs_limits(row['path']),'device':row['path']}),flush=True)
        elif data.get('action')=='install':execute(data,profile)
        else:raise ValueError('Unknown action')
    except Exception as error:
        print(json.dumps({'error':str(error)}),flush=True);raise SystemExit(1)
