import os,subprocess
from pathlib import Path

def administrator_start(args,demo=False):
    if demo or os.geteuid()==0:return None
    launcher=Path('/usr/share/dango-loader/launch-root.py')
    if not launcher.is_file():raise RuntimeError('Install the current Dango package before normal startup; use --demo to preview sources')
    return subprocess.run(['pkexec',str(launcher),*args],check=False).returncode
