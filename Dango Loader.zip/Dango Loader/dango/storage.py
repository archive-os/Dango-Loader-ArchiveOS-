"""Read-only discovery and pure partition plans. No disks are modified here."""
import json,re,subprocess,shutil,hashlib
from pathlib import Path
GIB=1024**3
MIB=1024**2

def capture(argv):
    return subprocess.check_output(argv,text=True,stderr=subprocess.PIPE,timeout=20)

def flatten(items,parent=None):
    result=[]
    for item in items:
        item=dict(item);children=item.pop('children',[]);item['disk']=parent or item.get('path');item['mountpoints']=[m for m in item.get('mountpoints',[]) or [] if m];result.append(item)
        result.extend(flatten(children,item['disk']))
    return result

def discover():
    rows=flatten(json.loads(capture(['lsblk','--json','--tree','--bytes','--paths','--output','NAME,PATH,TYPE,SIZE,FSTYPE,LABEL,UUID,PARTUUID,PKNAME,MOUNTPOINTS,RO,PTTYPE,PARTTYPE,SERIAL,WWN,MODEL,TRAN,RM']))['blockdevices'])
    systems=[];boot_entries=[]
    if shutil.which('efibootmgr'):
        try:boot_entries=capture(['efibootmgr','-v']).splitlines()
        except (OSError,subprocess.SubprocessError):pass
    for row in rows:
        for mount in row.get('mountpoints') or []:
            if not mount:continue
            file=Path(mount)/'etc/os-release'
            try:
                if file.is_file():
                    values=dict(re.findall(r'^(\w+)="?([^"\n]+)"?$',file.read_text(),re.M));systems.append({'device':row['path'],'name':values.get('PRETTY_NAME','Linux'),'kind':'linux','verified':True})
            except OSError:pass
        # Filesystem inspection is read-only and optional; never mount during GUI discovery.
        if row.get('fstype')=='ntfs' and shutil.which('ntfsls'):
            try:
                if capture(['ntfsls','-p','/Windows/System32',row['path']]).strip():systems.append({'device':row['path'],'name':'Windows','kind':'windows','verified':True})
            except (OSError,subprocess.SubprocessError):pass
        if row.get('type')=='part' and row.get('fstype') in ('ext4','btrfs','xfs') and not any(s['device']==row['path'] for s in systems):
            systems.append({'device':row['path'],'name':row.get('label') or 'Linux filesystem','kind':'linux','verified':False})
    return {'devices':rows,'systems':systems,'boot_entries':boot_entries,'uefi':Path('/sys/firmware/efi').is_dir(),'memory_mib':memory_mib()}

def memory_mib():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemTotal:'):return int(line.split()[1])//1024
    raise RuntimeError('Cannot determine system RAM')

BIOS_GRUB_GUID='21686148-6449-6e6f-744e-656564454649'
def bios_partition(inventory,disk):
    return next((r for r in eligible_partitions(inventory) if r.get('disk')==disk and str(r.get('parttype','')).lower()==BIOS_GRUB_GUID and int(r.get('size',0))>=1024**2),None)

def fixture():
    return {'uefi':True,'memory_mib':8192,'boot_entries':['Boot0000* Windows Boot Manager','Boot0001* Ubuntu'], 'systems':[{'device':'/dev/demo3','name':'Windows 11','kind':'windows','verified':True},{'device':'/dev/demo4','name':'Ubuntu','kind':'linux','verified':True}],
    'devices':[{'path':'/dev/demo','type':'disk','size':512*GIB,'pttype':'gpt','disk':'/dev/demo','mountpoints':[],'ro':False},
    {'path':'/dev/demo1','type':'part','fstype':'vfat','size':512*MIB,'disk':'/dev/demo','mountpoints':[],'ro':False,'uuid':'DEMO-EFI'},
    {'path':'/dev/demo3','type':'part','fstype':'ntfs','size':380*GIB,'disk':'/dev/demo','mountpoints':[],'ro':False,'uuid':'DEMO-WINDOWS'},
    {'path':'/dev/demo4','type':'part','fstype':'ext4','size':90*GIB,'disk':'/dev/demo','mountpoints':[],'ro':False,'uuid':'DEMO-LINUX'}]}

def eligible_partitions(inventory):
    return [r for r in inventory['devices'] if r.get('type')=='part' and not r.get('ro') and not any(r.get('mountpoints') or [])]

def device_identity(row):return row.get('uuid') or row.get('partuuid')
def disk_identity(row):
    payload={key:row.get(key) for key in ('path','size','serial','wwn','model')}
    return hashlib.sha256(json.dumps(payload,sort_keys=True).encode()).hexdigest()
def physical_disks(inventory):
    return [r for r in inventory['devices'] if r.get('type')=='disk' and not r.get('ro') and r.get('size',0)>0 and not r['path'].startswith(('/dev/zram','/dev/loop','/dev/ram','/dev/dm-'))]
def disk_is_busy(inventory,disk):return any(any(r.get('mountpoints') or []) for r in inventory['devices'] if r.get('disk')==disk or r.get('path')==disk)

def ntfs_limits(device):
    info=capture(['ntfsresize','--info','--no-progress-bar',device])
    match=re.search(r'You might resize at\s+(\d+)\s+bytes',info)
    if not match:raise ValueError('NTFS minimum size could not be determined; check Windows shutdown / BitLocker')
    return int(match[1])+GIB  # reserve additional filesystem headroom

def geometry(disk,device):
    lines=capture(['parted','--machine','--script',disk,'unit','B','print']).splitlines()
    match=re.search(r'(?:p)?(\d+)$',device)
    if not match:raise ValueError('Partition number is not identifiable')
    number=int(match[1])
    for line in lines:
        fields=line.rstrip(';').split(':')
        if fields[0]==str(number):return number,int(fields[1].rstrip('B')),int(fields[2].rstrip('B'))
    raise ValueError('Partition geometry is unavailable')

def alongside_layout(start,end,root_gib,ntfs_min_bytes):
    if not isinstance(root_gib,int) or root_gib<30:raise ValueError('At least 30 GiB is required')
    root_end=((end+1)//MIB)*MIB-1
    root_start=((root_end+1-root_gib*GIB)//MIB)*MIB
    windows_end=root_start-MIB-1
    windows_bytes=windows_end-start+1
    if windows_bytes<ntfs_min_bytes:raise ValueError('Windows would have insufficient space')
    if not start<windows_end<root_start<root_end<=end:raise ValueError('Invalid partition layout')
    return {'windows_bytes':windows_bytes,'windows_end':windows_end,'root_start':root_start,'root_end':root_end,'root_bytes':root_end-root_start+1}
