import re,json
from pathlib import Path
from .storage import GIB,eligible_partitions,physical_disks,disk_identity,disk_is_busy,device_identity,bios_partition,memory_mib,BIOS_GRUB_GUID
from .keyboards import keyboard_catalog
from .i18n import languages,locale_for

def load_profile(file):
    data=json.loads(Path(file).read_text())
    if data.get('family')!='debian' or data.get('bootloader_target') not in ('x86_64-efi','auto'):raise ValueError('This backend supports Debian-family x86_64 images')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,32}',data.get('bootloader_id','')):raise ValueError('Invalid bootloader ID')
    if not Path(data.get('source_image','')).is_absolute():raise ValueError('Source image must be absolute')
    return data

def validate_user(data):
    if not re.fullmatch(r'[a-z][a-z0-9_-]{0,30}',data.get('username','')) or data['username'] in ('root','daemon','nobody'):raise ValueError('Use a lowercase username beginning with a letter')
    if not re.fullmatch(r'[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?',data.get('hostname','')):raise ValueError('Invalid computer name')
    if not isinstance(data.get('fullname'),str) or len(data['fullname'])>80 or any(c in data['fullname'] for c in ':\n\r\0'):raise ValueError('Invalid full name')
    password=data.get('password','')
    secure=data.get('secure_password',True)
    if not isinstance(secure,bool):raise ValueError('Invalid password policy')
    minimum=8 if secure else 1
    if not isinstance(password,str) or len(password)<minimum or any(c in password for c in '\n\r\0'):raise ValueError(f'A sudo password of at least {minimum} character(s) is required')
    zone=data.get('timezone','')
    if not re.fullmatch(r'[A-Za-z0-9_+/-]{1,100}',zone) or '..' in zone or not (Path('/usr/share/zoneinfo')/zone).resolve().is_relative_to(Path('/usr/share/zoneinfo').resolve()) or not (Path('/usr/share/zoneinfo')/zone).is_file():raise ValueError('Invalid timezone')
    layout='tr' if data.get('keyboard')=='tr-f' else data.get('keyboard');variant='f' if data.get('keyboard')=='tr-f' else data.get('keyboard_variant','');catalog=keyboard_catalog()
    if layout not in catalog or variant not in catalog[layout]['variants']:raise ValueError('Invalid keyboard layout or variant')
    if data.get('language') not in languages():raise ValueError('Invalid language')

def minimum_disk_bytes(profile):return max(32_000_000_000,int(profile.get('minimum_install_bytes',32_000_000_000)))
def minimum_root_bytes(inventory,profile):
    return minimum_disk_bytes(profile)-(514 if inventory.get('uefi') else 4)*1024**2

def validate_hardware(inventory,profile):
    # /proc reports usable RAM. A 4-GiB machine may reserve up to 256 MiB for firmware/kernel.
    detected=inventory.get('memory_mib')
    if detected is None:detected=memory_mib()
    if int(detected)<max(4096,int(profile.get('minimum_ram_mib',4096)))-256:raise ValueError('At least 4 GiB RAM is required')

def validate_plan(data,inventory,profile):
    validate_user(data)
    return validate_storage(data,inventory,profile)

def validate_storage(data,inventory,profile):
    validate_hardware(inventory,profile)
    if data.get('filesystem') not in ('ext4','btrfs','xfs'):raise ValueError('Select a supported filesystem')
    if data.get('swap') not in ('auto','off'):raise ValueError('Select a swap policy')
    rows={r['path']:r for r in eligible_partitions(inventory)}
    if data.get('mode') not in ('manual','alongside','erase'):raise ValueError('Unknown installation mode')
    if data['mode']=='erase':
        disk=next((r for r in physical_disks(inventory) if r['path']==data.get('disk_device')),None)
        if not disk or disk_is_busy(inventory,disk['path']):raise ValueError('Choose an unused physical disk; live media and mounted disks cannot be erased')
        if int(disk['size'])<minimum_disk_bytes(profile):raise ValueError(f'Disk is too small: {int(disk["size"])/1e9:.2f} GB detected; {minimum_disk_bytes(profile)/1e9:.2f} GB total required (boot partitions included)')
        if data.get('erase_confirmed') is not True:raise ValueError('Erasing the entire disk must be explicitly confirmed')
        if data.get('disk_identity')!=disk_identity(disk):raise ValueError('Selected disk identity changed; scan again')
        return disk,None
    root=rows.get(data.get('root_device'));efi=rows.get(data.get('efi_device'))
    if not root:raise ValueError('Choose an unmounted root partition')
    if inventory.get('uefi') and (not efi or root['path']==efi['path']):raise ValueError('Choose separate unmounted root and EFI partitions')
    if inventory.get('uefi') and root.get('disk')!=efi.get('disk'):raise ValueError('Root and EFI must be on the same disk in this initial profile')
    disk=next((r for r in inventory['devices'] if r['path']==root.get('disk')),None)
    if not disk or disk.get('pttype') not in ('gpt','dos','msdos'):raise ValueError('A GPT or MBR disk is required')
    if data.get('disk_device'):
        if disk['path']!=data['disk_device']:raise ValueError('Selected root partition is not on the selected installation disk')
        if data.get('disk_identity')!=disk_identity(disk):raise ValueError('Selected installation disk identity changed; scan again')
    if inventory.get('uefi') and disk.get('pttype')!='gpt':raise ValueError('UEFI installation requires GPT')
    if str(root.get('parttype','')).lower()==BIOS_GRUB_GUID:raise ValueError('The BIOS boot partition must be preserved')
    if not inventory.get('uefi'):
        if disk.get('pttype')=='gpt' and not bios_partition(inventory,disk['path']):raise ValueError('BIOS on GPT needs an unused bios_grub partition of at least 1 MiB; create it with Advanced')
        if data['mode']=='alongside':
            parts=[r for r in inventory['devices'] if r.get('type')=='part' and r.get('disk')==disk['path']]
            if disk.get('pttype')=='gpt':raise ValueError('Windows on GPT needs UEFI for compatible dual boot')
            if len(parts)>=4 or any(str(r.get('parttype','')).lower() in ('0x5','0x05','0xf','0x0f','0x85') for r in parts):raise ValueError('BIOS Windows dual boot needs a free primary MBR partition slot; extended layouts require Advanced')
    if any(any(r.get('mountpoints') or []) for r in inventory['devices'] if r.get('disk')==root['disk']):raise ValueError('A partition on this disk is in use; do not install onto the running system or live media')
    if inventory.get('uefi') and (efi.get('fstype') not in ('vfat','fat','fat32') or int(efi.get('size',0))<256*1024**2):raise ValueError('Choose a FAT EFI partition of at least 256 MiB')
    if data['mode']=='manual':
        if int(root.get('size',0))<minimum_root_bytes(inventory,profile):raise ValueError(f'Root partition is too small: {int(root.get("size",0))/1e9:.2f} GB detected; {minimum_root_bytes(inventory,profile)/1e9:.2f} GB required alongside the boot partition')
        if data.get('format_confirmed') is not True:raise ValueError('Root formatting must be explicitly confirmed')
    else:
        if root.get('fstype')!='ntfs':raise ValueError('Alongside currently requires an unencrypted NTFS Windows partition')
        if not isinstance(data.get('root_gib'),int) or data['root_gib']*GIB<minimum_root_bytes(inventory,profile):raise ValueError('New system needs more space')
        if data.get('resize_confirmed') is not True:raise ValueError('Windows resizing must be explicitly confirmed')
    if not device_identity(root) or device_identity(root)!=data.get('root_uuid') or (inventory.get('uefi') and (not device_identity(efi) or device_identity(efi)!=data.get('efi_uuid'))):raise ValueError('Selected device identity changed; scan again')
    return root,efi if inventory.get('uefi') else None

def public_plan(data):
    return {k:v for k,v in data.items() if k not in ('password','password_confirmation')}
