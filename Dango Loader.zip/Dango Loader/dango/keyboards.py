import re
from functools import lru_cache
from pathlib import Path
from xml.etree import ElementTree

@lru_cache(maxsize=1)
def keyboard_catalog():
    layouts={};file=Path('/usr/share/X11/xkb/rules/evdev.xml')
    if file.exists():
        for layout in ElementTree.parse(file).findall('./layoutList/layout'):
            name=layout.findtext('./configItem/name');description=layout.findtext('./configItem/description')
            if not name or not re.fullmatch(r'[a-zA-Z0-9_-]{1,32}',name):continue
            variants={'': 'Standard'}
            for variant in layout.findall('./variantList/variant'):
                key=variant.findtext('./configItem/name')
                if key and re.fullmatch(r'[a-zA-Z0-9_-]{1,40}',key):variants[key]=variant.findtext('./configItem/description') or key
            layouts[name]={'name':description or name,'variants':variants}
    if not layouts:
        for key,name in [('us','English (US)'),('tr','Turkish'),('gb','English (UK)'),('de','German'),('fr','French'),('es','Spanish'),('it','Italian'),('ru','Russian'),('ara','Arabic'),('br','Portuguese (Brazil)'),('jp','Japanese'),('kr','Korean')]:layouts[key]={'name':name,'variants':{'':'Standard'}}
        layouts['tr']['variants']['f']='Turkish (F)'
    return layouts

