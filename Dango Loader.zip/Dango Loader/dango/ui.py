import json,os,shutil
from zoneinfo import available_timezones
from pathlib import Path
from PyQt6.QtCore import Qt,QEvent,QLocale,QTimer,QThread,pyqtSignal,QProcess,QPropertyAnimation,QEasingCurve,QSize
from PyQt6.QtGui import QColor,QPixmap,QIcon,QPainter,QPen,QPalette,QFont
from PyQt6.QtWidgets import *
from .branding import load_branding,language,text
from . import __version__
from .location import TimezoneMap
from .keyboards import keyboard_catalog
from .i18n import translate,languages
from .session_keyboard import apply_keyboard
from .model import load_profile,validate_plan,public_plan,validate_storage,validate_hardware
from .storage import discover,fixture,eligible_partitions,GIB,physical_disks,disk_identity,device_identity
from .engine import ram_mib,swap_mib

class Probe(QThread):
    ready=pyqtSignal(object);failed=pyqtSignal(str)
    def run(self):
        try:self.ready.emit(discover())
        except Exception as error:self.failed.emit(str(error))

class AllocationBar(QWidget):
    changed=pyqtSignal(int)
    def __init__(self):super().__init__();self.total=380;self.value=60;self.minimum=30;self.maximum=200;self.dark=False;self.accent=QColor('#78cbf5');self.setMinimumHeight(72);self.setCursor(Qt.CursorShape.SplitHCursor)
    def setValue(self,value):self.value=max(self.minimum,min(self.maximum,int(value)));self.update();self.changed.emit(self.value)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);w=max(1,self.width()-4);retained=1-self.value/max(1,self.total)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#2b3e4c' if self.dark else '#e9eef4'));p.drawRoundedRect(2,8,w,48,12,12)
        p.setBrush(self.accent);p.drawRoundedRect(int(2+w*retained),8,max(1,int(w*(1-retained))),48,12,12)
        x=int(2+w*retained);p.setPen(QPen(QColor('#456575'),3));p.drawLine(x,16,x,48)
        p.setPen(QColor('#e5eff6' if self.dark else '#263c4a'));p.drawText(14,38,f'Windows  {self.total-self.value} GiB');p.setPen(QColor('#163344'));p.drawText(max(x+12,self.width()-158),38,f'{self.value} GiB')
    def mousePressEvent(self,event):self.mouseMoveEvent(event)
    def mouseMoveEvent(self,event):
        if event.buttons() & Qt.MouseButton.LeftButton:self.setValue(round(self.total*(1-event.position().x()/max(1,self.width()))))

class SlideView(QLabel):
    """Fit the original image to available space, including narrow live screens."""
    def __init__(self):
        super().__init__();self.original=QPixmap();self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumWidth(1);self.setMinimumHeight(300)
        self.setSizePolicy(QSizePolicy.Policy.Ignored,QSizePolicy.Policy.Expanding)
    def set_image(self,path):self.original=QPixmap(str(path));self.refresh()
    def refresh(self):
        if not self.original.isNull():self.setPixmap(self.original.scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
    def resizeEvent(self,event):super().resizeEvent(event);self.refresh()

class Installer(QMainWindow):
    def __init__(self,root,branding=None,lang=None,demo=False):
        super().__init__();self.root=Path(root);self.brand=load_branding(branding or self.root/'branding');self.profile=load_profile(self.root/'installer.json' if (self.root/'installer.json').exists() else '/etc/dango-loader/installer.json')
        self.lang=lang or language();self.demo=demo;self.inventory=fixture() if demo else {'devices':[],'systems':[],'boot_entries':[],'uefi':False};self.busy=False;self.step=0;self.workers=[];self.slide_index=0;self.ntfs_min=None;self.ntfs_device=None;self.running_animation=None;self.buffer=b'';self.resize(1120,780);self.setMinimumSize(900,680)
        self.system_dark=QApplication.palette().color(QPalette.ColorRole.Window).lightness()<128;self.dark=False;self.build();self.fill_devices();self.slide_timer=QTimer(self);self.slide_timer.timeout.connect(self.next_slide);self.slide_timer.setInterval(self.brand['slides_interval_ms'])
        if not demo:QTimer.singleShot(0,self.scan)
    def t(self,tr,en):return translate(self.lang,en,tr)
    def label(self,value,kind=None):
        widget=QLabel(value);widget.setTextFormat(Qt.TextFormat.PlainText);widget.setWordWrap(True)
        if kind:widget.setObjectName(kind)
        return widget
    def button(self,value,fn,primary=False):
        b=QPushButton(value);b.clicked.connect(fn)
        if primary:b.setObjectName('primary')
        return b
    def skin(self):
        mode=self.theme_choice.currentData() if hasattr(self,'theme_choice') else 'system';scheme=QApplication.styleHints().colorScheme();self.dark=(scheme==Qt.ColorScheme.Dark if scheme!=Qt.ColorScheme.Unknown else self.system_dark) if mode=='system' else mode=='dark'
        accent=QColor(self.brand['accent']);tint=QColor(round(accent.red()*.16+255*.84),round(accent.green()*.16+255*.84),round(accent.blue()*.16+255*.84)).name();self.bar.accent=accent if hasattr(self,'bar') else accent
        palette=QPalette()
        roles={'Window':self.brand['background'],'WindowText':'#203340','Base':'#ffffff','AlternateBase':'#edf6fc','Text':'#203340','Button':'#ffffff','ButtonText':'#203340','BrightText':'#ffffff','Highlight':self.brand['accent'],'HighlightedText':'#163344','ToolTipBase':'#203340','ToolTipText':'#ffffff','PlaceholderText':'#708492','Link':'#1679b0'}
        if self.dark:roles.update({'Window':'#141e27','WindowText':'#e5eff6','Base':'#1e2b36','AlternateBase':'#243745','Text':'#e5eff6','Button':'#24333f','ButtonText':'#e5eff6','PlaceholderText':'#9ab1c0'})
        for name,color in roles.items():
            for group in (QPalette.ColorGroup.Active,QPalette.ColorGroup.Inactive,QPalette.ColorGroup.Disabled):
                palette.setColor(group,getattr(QPalette.ColorRole,name),QColor(color))
        palette.setColor(QPalette.ColorGroup.Disabled,QPalette.ColorRole.Text,QColor('#83929c'))
        self.setPalette(palette)
        for combo in self.findChildren(QComboBox):combo.setPalette(palette);combo.view().setPalette(palette)
        stylesheet=f'''
QMainWindow,QWidget#shell {{background:{self.brand['background']};}}
QWidget {{font-family:"Noto Sans","DejaVu Sans";font-size:13px;color:#203340;}}
QFrame#sidebar {{background:{tint};border-radius:18px;}}
QFrame#card {{background:#ffffff;border:1px solid #dce7ee;border-radius:16px;}}
QLabel {{background:transparent;}}
QLabel#hero {{font-size:28px;font-weight:700;}} QLabel#title {{font-size:23px;font-weight:700;}}
QLabel#muted {{color:#587385;}} QLabel#small {{font-size:11px;color:#587385;}}
QPushButton {{color:#203340;border:1px solid #cbdce6;background:#ffffff;border-radius:9px;padding:10px 14px;min-height:18px;}}
QPushButton:hover {{background:{tint};border-color:{self.brand['accent']};}}
QPushButton:pressed {{background:#d6edf9;}}
QPushButton:focus {{border:2px solid #328fc1;}}
QPushButton#primary {{background:{self.brand['accent']};color:#163344;border:1px solid {self.brand['accent']};font-weight:700;}}
QPushButton:disabled {{background:#edf1f4;color:#83929c;border-color:#e2e9ee;}}
QPushButton#step {{text-align:left;padding:10px 8px;border:0;background:transparent;}}
QPushButton#step:disabled {{color:#678393;background:transparent;}}
QPushButton#step[current="true"] {{background:#ffffff;color:#163344;font-weight:700;}}
QLineEdit,QComboBox,QSpinBox {{padding:8px 10px;border:1px solid #cbdce6;border-radius:8px;background:#ffffff;color:#203340;min-height:20px;selection-background-color:{self.brand['accent']};selection-color:#163344;}}
QLineEdit:focus,QComboBox:focus,QSpinBox:focus {{border:1px solid #328fc1;background:#f7fcff;}}
QComboBox::drop-down {{border:0;width:26px;}} QComboBox::down-arrow {{image:url("{self.root}/chevron.svg");width:12px;height:8px;}}
QComboBox QAbstractItemView {{background:#ffffff;color:#203340;selection-background-color:{tint};selection-color:#163344;border:1px solid #cbdce6;outline:0;padding:4px;}}
QCheckBox,QRadioButton {{spacing:9px;padding:4px 0;color:#203340;}}
QCheckBox::indicator {{width:17px;height:17px;border:1px solid #9cb5c5;border-radius:4px;background:#ffffff;}}
QCheckBox::indicator:checked {{background:#227fac;border-color:#227fac;image:url("{self.root}/check.svg");}}
QRadioButton::indicator {{width:17px;height:17px;border:1px solid #9cb5c5;border-radius:9px;background:#ffffff;}}
QRadioButton::indicator:checked {{background:#227fac;border:4px solid #dceffa;}}
QCheckBox:disabled,QRadioButton:disabled {{color:#83929c;}}
QProgressBar {{border:0;border-radius:6px;background:#e8eef3;min-height:12px;max-height:12px;}}
QProgressBar::chunk {{background:{self.brand['accent']};border-radius:6px;}}
QScrollArea,QStackedWidget {{border:0;background:transparent;}}
QScrollBar:vertical {{background:#f3f7fa;width:8px;margin:4px 0;}}
QScrollBar::handle:vertical {{background:#c2d5e1;border-radius:4px;min-height:35px;}}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {{height:0;}}
QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical {{background:transparent;}}
QPlainTextEdit {{background:#17252f;color:#dbeef8;border:0;border-radius:10px;font-family:"DejaVu Sans Mono";font-size:11px;padding:10px;}}
QToolTip {{background:#203340;color:#ffffff;border:0;padding:6px;}}
'''
        if self.dark:
            for old,new in [(self.brand['background'],'#141e27'),(tint,'#243b4c'),('#ffffff','#1e2b36'),('#203340','#e5eff6'),('#163344','#d8eefb'),('#587385','#9fb7c6'),('#678393','#9fb7c6'),('#83929c','#708995'),('#cbdce6','#3f5565'),('#dce7ee','#334958'),('#edf1f4','#23313b'),('#e2e9ee','#334958'),('#f7fcff','#243a4a'),('#f3f7fa','#182630'),('#c2d5e1','#496579'),('#e8eef3','#2b3e4c'),('#dceffa','#334f62'),('#d6edf9','#2e4658')]:stylesheet=stylesheet.replace(old,new)
            stylesheet+='\nQPushButton#primary {color:#092c42;} QCheckBox::indicator:checked {image:url("'+str(self.root/'check.svg')+'");} QComboBox QAbstractItemView::item:selected {color:#e5eff6;}'
        self.setStyleSheet(stylesheet)
        self.bar.dark=self.dark;self.bar.update()
        if hasattr(self,'timezone_map'):self.timezone_map.dark=self.dark;self.timezone_map.update()
        if hasattr(self,'slide'):self.update_slide()
        self.setWindowTitle(text(self.brand['window_title'],self.lang));self.setWindowIcon(QIcon(str(self.root/'dango-loader.png')))
    def build(self):
        shell=QWidget();shell.setObjectName('shell');self.setCentralWidget(shell);layout=QHBoxLayout(shell);layout.setContentsMargins(20,20,20,20);layout.setSpacing(18)
        side=QFrame();self.sidebar=side;side.setObjectName('sidebar');side.setFixedWidth(212);left=QVBoxLayout(side);left.setContentsMargins(20,24,20,22)
        logo=QLabel();logo.setFixedSize(72,72);logo.setPixmap(QPixmap(str(self.root/'dango-loader.png')).scaled(68,68,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));left.addWidget(logo)
        left.addWidget(self.label('Dango Loader','title'));left.addWidget(self.label(self.brand['name'],'muted'));left.addSpacing(12)
        titles=[self.t('Hoş geldin','Welcome'),self.t('Bölge','Location'),self.t('Klavye','Keyboard'),self.t('Bölümler','Partitions'),self.t('Kullanıcı','User'),self.t('Özet','Summary'),self.t('Kurulum','Installation'),self.t('Tamamlandı','Finish')]
        self.steps=[]
        for index,title in enumerate(titles):
            b=self.button(f'{index+1:02}   {title}',lambda _,i=index:self.go(i) if i<=self.step and not self.busy else None);b.setObjectName('step');self.steps.append(b);left.addWidget(b)
        left.addStretch();left.addWidget(self.label(self.lang+'  ·  '+__version__,'small'));layout.addWidget(side)
        right=QVBoxLayout();right.setSpacing(12)
        self.pages=QStackedWidget();right.addWidget(self.pages,1)
        self.error_label=self.label('','muted');self.error_label.setMaximumHeight(48);right.addWidget(self.error_label)
        footer=QHBoxLayout();self.mode_label=self.label(self.t('Önizleme · disk değişiklikleri yapılmaz','Preview · no disk changes') if self.demo else self.t('Live ISO kurulum sihirbazı','Live ISO installation wizard'),'small');footer.addWidget(self.mode_label,1)
        self.back=self.button(self.t('Geri','Back'),self.previous);self.next=self.button(self.t('İleri','Next'),self.advance,True);footer.addWidget(self.back);footer.addWidget(self.next);right.addLayout(footer);layout.addLayout(right,1)
        self.welcome_page();self.location_page();self.keyboard_page();self.storage_page();self.user_page();self.summary_page();self.install_page();self.finish_page();self.skin();self.go(0,False)
    def page(self,title,subtitle):
        scroll=QScrollArea();scroll.setWidgetResizable(True);card=QFrame();card.setObjectName('card');box=QVBoxLayout(card);box.setContentsMargins(24,22,24,22);box.setSpacing(12);box.addWidget(self.label(title,'title'));box.addWidget(self.label(subtitle,'muted'));scroll.setWidget(card);self.pages.addWidget(scroll);return box
    def welcome_page(self):
        box=self.page(self.t('Hoş geldin!','Welcome!'),self.t('Hadi, '+self.brand['name']+' sistemini birlikte hazırlayalım.','Let’s get your '+self.brand['name']+' system ready.'))
        mark=QLabel();mark.setFixedHeight(115);mark.setAlignment(Qt.AlignmentFlag.AlignCenter);mark.setPixmap(QPixmap(self.brand['logo_path']).scaled(100,100,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));box.addWidget(mark)
        box.addWidget(self.label(self.t('Birkaç seçim yapacağız. Başlamadan önce her şeyi birlikte gözden geçireceğiz. Hazırsan İleri’ye tıkla.','We’ll make a few choices, then review them together before starting. Click Next whenever you’re ready.')))
        box.addWidget(self.label(self.t('Dil','Language'),'muted'));self.language_choice=QComboBox()
        for code in languages():
            locale=QLocale(code);name=locale.nativeLanguageName() or code;country=locale.nativeTerritoryName();self.language_choice.addItem(name+(' · '+country if '_' in code else ''),code)
        self.language_choice.setCurrentIndex(max(0,self.language_choice.findData(self.lang)));self.language_choice.currentIndexChanged.connect(self.change_language)
        box.addWidget(self.language_choice);box.addWidget(self.label(self.t('Gereksinimler: başlatma bölümleri dahil en az 32 GB kurulum alanı ve 4 GiB RAM. UEFI ve BIOS desteklenir.','Requirements: at least 32 GB total installation space, including boot partitions and 4 GiB RAM. UEFI and BIOS are supported.'),'small'));box.addSpacing(10);box.addWidget(self.label(self.t('Kurucunun görünümü','Installer appearance'),'muted'));self.theme_choice=QComboBox()
        for title,key in [(self.t('Sisteme göre','Follow system'),'system'),(self.t('Siyah','Dark'),'dark'),(self.t('Beyaz','Light'),'light')]:self.theme_choice.addItem(title,key)
        self.theme_choice.currentIndexChanged.connect(self.skin);box.addWidget(self.theme_choice);box.addStretch()
        QApplication.styleHints().colorSchemeChanged.connect(self.system_theme_changed)
    def change_language(self):
        code=self.language_choice.currentData()
        if code==self.lang:return
        old=self.plan();theme=self.theme_choice.currentData();self.keyboard_timer.stop();self.lang=code
        self.setLayoutDirection(QLocale(code).textDirection());self.build();self.fill_devices()
        self.theme_choice.setCurrentIndex(self.theme_choice.findData(theme))
        self.zone.setCurrentText(old['timezone']);self.keyboard.setCurrentIndex(self.keyboard.findData(old['keyboard']))
        self.keyboard_variants.setCurrentIndex(max(0,self.keyboard_variants.findData(old['keyboard_variant'])))
        self.secure_password.setChecked(old.get('secure_password',True))
        for field,key in ((self.fullname,'fullname'),(self.username,'username'),(self.hostname,'hostname'),(self.password,'password'),(self.confirm_password,'password')):field.setText(old[key])
    def location_page(self):
        box=self.page(self.t('Nerede yaşıyorsun?','Where are you based?'),self.t('Saat dilimini seç. Yerel saat buna göre ayarlanacak.','Choose a timezone for your local clock.'))
        self.zone=QComboBox();self.zone.setEditable(False);zones=['UTC']
        zones+=sorted(available_timezones()-{'UTC'})
        self.zone.addItems(zones);self.zone.setCurrentText('Europe/Istanbul' if self.lang.startswith('tr') else 'UTC');box.addWidget(self.label(self.t('Saat dilimi','Timezone')));box.addWidget(self.zone);self.timezone_map=TimezoneMap(self.root/'world.geojson',self.brand['accent']);box.addWidget(self.timezone_map);box.addWidget(self.label(self.t('Haritadaki noktalar saat dilimlerini temsil eder. Tıklayınca en yakın nokta seçilir; listeden de değiştirebilirsin.','Map points represent timezones. Click to select the nearest point, or choose from the list.'),'small'));self.timezone_map.selected.connect(self.zone.setCurrentText);self.zone.currentTextChanged.connect(self.timezone_map.set_zone);self.timezone_map.set_zone(self.zone.currentText());box.addStretch()
    def keyboard_page(self):
        box=self.page(self.t('Klavye düzenini seç','Choose your keyboard'),self.t('Rahat ettiğin düzeni seç; live klavyen de bu seçime göre değişecek.','Choose a layout. The live keyboard changes with your selection.'))
        self.keyboard=QComboBox();self.keyboard_variants=QComboBox();self.keyboards=keyboard_catalog()
        translations={'tr':'Türkçe','us':'İngilizce (ABD)','gb':'İngilizce (Birleşik Krallık)','de':'Almanca','fr':'Fransızca','es':'İspanyolca','it':'İtalyanca','ru':'Rusça','ara':'Arapça','br':'Portekizce (Brezilya)','jp':'Japonca','kr':'Korece'}
        for key,data in sorted(self.keyboards.items(),key=lambda item:item[1]['name']):self.keyboard.addItem(translations.get(key,data['name']) if self.lang.startswith('tr') else data['name'],key)
        self.keyboard.currentIndexChanged.connect(self.fill_keyboard_variants);self.keyboard.setCurrentIndex(self.keyboard.findData('tr' if self.lang.startswith('tr') else 'us'));self.fill_keyboard_variants()
        box.addWidget(self.label(self.t('Klavye dili / düzeni','Keyboard language / layout')));box.addWidget(self.keyboard);box.addWidget(self.label(self.t('Klavye türü / varyantı','Keyboard type / variant')));box.addWidget(self.keyboard_variants)
        self.keyboard_status=self.label('','small');box.addWidget(self.keyboard_status);box.addStretch();self.keyboard_timer=QTimer(self);self.keyboard_timer.setSingleShot(True);self.keyboard_timer.setInterval(250);self.keyboard_timer.timeout.connect(self.apply_live_keyboard);self.keyboard.currentIndexChanged.connect(lambda _:self.keyboard_timer.start());self.keyboard_variants.currentIndexChanged.connect(lambda _:self.keyboard_timer.start())
    def fill_keyboard_variants(self):
        self.keyboard_variants.clear()
        for key,title in self.keyboards.get(self.keyboard.currentData(),{'variants':{'':'Standard'}})['variants'].items():
            if not key:title=self.t('Standart (Q)' if self.keyboard.currentData()=='tr' else 'Standart','Standard')
            elif self.keyboard.currentData()=='tr' and key=='f':title=self.t('Türkçe F','Turkish (F)')
            self.keyboard_variants.addItem(title,key)
    def apply_live_keyboard(self):
        try:
            apply_keyboard(self.keyboard.currentData(),self.keyboard_variants.currentData() or '',self.demo)
            self.keyboard_status.setText(self.t('Klavye düzeni seçildi (önizleme).' if self.demo else 'Klavye düzeni uygulandı.','Keyboard selected (preview).' if self.demo else 'Keyboard layout applied.'))
        except Exception as error:self.keyboard_status.setText(str(error))
    def storage_page(self):
        box=self.page(self.t('Kurulum yöntemini seç','Partitions'),self.t('İhtiyacına uygun seçeneği aç. Son adımda değişiklikleri gözden geçireceğiz.','Choose an installation method. We will review the changes before starting.'))
        self.storage_title=box.itemAt(0).widget();self.storage_description=box.itemAt(1).widget()
        self.disk_controls=QWidget();controls=QVBoxLayout(self.disk_controls);controls.setContentsMargins(0,0,0,0)
        self.systems_label=self.label('','small');controls.addWidget(self.systems_label)
        row=QHBoxLayout();self.scan_button=self.button(self.t('Disk algılama','Detect disks'),self.scan);row.addWidget(self.scan_button);row.addWidget(self.button(self.t('Gelişmiş','Advanced'),self.open_partition_manager));controls.addLayout(row)
        self.detected_disks=self.label('','small');controls.addWidget(self.detected_disks);box.addWidget(self.disk_controls)
        self.storage_stack=QStackedWidget();box.addWidget(self.storage_stack);self.storage_mode='manual'
        options=QWidget();choices=QVBoxLayout(options);choices.setContentsMargins(0,0,0,0);choices.setSpacing(16)
        self.dualboot_button=self.button(self.t('Windows yanında kur','Install alongside Windows'),lambda:self.select_storage('alongside'));choices.addWidget(self.dualboot_button)
        choices.addWidget(self.label(self.t('Windows korunur. Yeni sisteme ayıracağın alanı sürükleyerek seç.','Keep Windows and drag to choose space for your new system.'),'small'))
        choices.addWidget(self.button(self.t('Diski sil ve kur','Erase disk and install'),lambda:self.select_storage('erase')))
        choices.addWidget(self.label(self.t('Seçtiğin diskin tamamı silinir; yeni bölümler oluşturulur.','Erase the selected disk and create fresh partitions.'),'small'))
        choices.addWidget(self.button(self.t('Hazır bölüme kur','Manual partitioning'),lambda:self.select_storage('manual')));choices.addStretch();self.storage_stack.addWidget(options)
        details=QWidget();fields=QVBoxLayout(details);fields.setContentsMargins(0,0,0,0);fields.setSpacing(10)
        self.manual=QRadioButton();self.alongside=QRadioButton();self.erase=QRadioButton();self.mode_group=QButtonGroup(self)
        for button in (self.manual,self.alongside,self.erase):self.mode_group.addButton(button);fields.addWidget(button);button.hide()
        self.manual.setChecked(True);self.alongside.toggled.connect(self.mode_changed)
        self.disk_combo=QComboBox();self.disk_label=self.label(self.t('Kurulum diski','Installation disk'));controls.addWidget(self.disk_label);controls.addWidget(self.disk_combo)
        self.root_combo=QComboBox();self.efi_combo=QComboBox();self.root_label=self.label(self.t('Kurulum bölümü','Installation partition'));self.efi_label=self.label(self.t('EFI bölümü korunur','EFI partition (preserved)'));fields.addWidget(self.root_label);fields.addWidget(self.root_combo);fields.addWidget(self.efi_label);fields.addWidget(self.efi_combo)
        self.allocation=QWidget();allocation=QVBoxLayout(self.allocation);allocation.setContentsMargins(0,0,0,0);self.bar=AllocationBar();allocation.addWidget(self.label(self.t('Yeni sistem için alanı sürükle','Drag to allocate space for the new system')));allocation.addWidget(self.bar)
        row=QHBoxLayout();self.size=QSpinBox();self.size.setRange(30,200);self.size.setValue(60);self.size.setSuffix(' GiB');row.addWidget(self.size);self.limits_button=self.button(self.t('Uygun alanı kontrol et','Check available space'),self.check_limits);row.addWidget(self.limits_button);allocation.addLayout(row)
        self.limits_label=self.label('','small');allocation.addWidget(self.limits_label);fields.addWidget(self.allocation);self.allocation.hide();self.bar.changed.connect(self.size.setValue);self.size.valueChanged.connect(self.bar.setValue);self.root_combo.currentIndexChanged.connect(self.root_changed)
        self.fs=QComboBox();self.fs.addItems(['Btrfs','Ext4']);fields.addWidget(self.label(self.t('Dosya sistemi','Filesystem')));fields.addWidget(self.fs)
        fields.addWidget(self.label(self.t('Btrfs önerilir: snapshot araçları için uygundur.','Btrfs is recommended for snapshot tools.'),'small'))
        self.disk_warning=self.label('','muted');fields.addWidget(self.disk_warning);self.disk_confirm=QCheckBox(self.t('Bu disk değişikliklerini onaylıyorum','I approve these disk changes'));fields.addWidget(self.disk_confirm);fields.addStretch();self.storage_stack.addWidget(details)
        memory=QWidget();settings=QVBoxLayout(memory);settings.setContentsMargins(0,0,0,0);settings.addWidget(self.label(self.t('Zram açılsın mı?','Enable zram?'),'title'));settings.addWidget(self.label(self.t('Bellek dolduğunda sıkıştırılmış RAM alanı yardımcı olur.','Compressed memory helps when RAM fills up.')))
        self.zram=QCheckBox(self.t('Zram kullan — önerilen ayar','Use zram — recommended'));self.zram.setChecked(True);self.zram.setStyleSheet("font-weight: 600;");settings.addWidget(self.zram)
        settings.addWidget(self.label(self.t('RAM miktarına göre otomatik ayarlanır. Hem dual boot hem temiz kurulum için önerilir.','Sized automatically for your RAM. Recommended for dual boot and clean installation.'),'small'));settings.addStretch();self.storage_stack.addWidget(memory)
        self.storage_stack.currentChanged.connect(self.storage_stage_changed)
        self.swap=QComboBox();self.swap.addItem('Automatic','auto');self.swap.addItem('Off','off');self.swap.hide();self.zram.toggled.connect(lambda on:self.swap.setCurrentIndex(0 if on else 1))
        self.disk_combo.currentIndexChanged.connect(self.selected_disk_changed);box.addStretch()
    def storage_stage_changed(self,index):
        memory=index==2;self.disk_controls.setVisible(not memory)
        self.storage_title.setText(self.t('Bellek ayarları','Memory settings') if memory else self.t('Kurulum yöntemini seç','Partitions'))
        self.storage_description.setText(self.t('Zram tercihini seç; önerilen ayar açık kalmasıdır.','Choose your zram preference; enabling it is recommended.') if memory else self.t('İhtiyacına uygun seçeneği aç. Son adımda değişiklikleri gözden geçireceğiz.','Choose an installation method. We will review the changes before starting.'))
        self.error_label.clear()
    def select_storage(self,mode):
        if not self.disk_combo.currentData():self.error_label.setText(self.t('Önce Disk algılama ile bir disk seç.','Detect disks and select an installation disk first.'));return
        if mode=='alongside' and not any(r.get('disk')==self.disk_combo.currentData() and r.get('fstype')=='ntfs' for r in eligible_partitions(self.inventory)):self.error_label.setText(self.t('Seçili diskte uygun Windows bölümü bulunamadı.','No suitable Windows partition was found on the selected disk.'));return
        self.storage_mode=mode
        {'manual':self.manual,'alongside':self.alongside,'erase':self.erase}[mode].setChecked(True)
        self.storage_stack.setCurrentIndex(1);self.disk_confirm.setChecked(False);self.fill_partitions();self.mode_changed()
    def user_page(self):
        box=self.page(self.t('Bu bilgisayar senin','Make it yours'),self.t('Sana nasıl hitap edelim? Hesabını burada hazırlayalım.','What should we call you? Let’s set up your account here.'));form=QFormLayout();form.setSpacing(14)
        self.fullname=QLineEdit();self.username=QLineEdit();self.hostname=QLineEdit(self.brand['short_name'].lower()+'-pc');self.password=QLineEdit();self.confirm_password=QLineEdit()
        for field in (self.password,self.confirm_password):field.setEchoMode(QLineEdit.EchoMode.Password)
        for title,field in [(self.t('Ad soyad','Full name'),self.fullname),(self.t('Kullanıcı adı','Username'),self.username),(self.t('Bilgisayar adı','Computer name'),self.hostname),(self.t('Parola','Password'),self.password),(self.t('Parolayı doğrula','Confirm password'),self.confirm_password)]:form.addRow(title,field)
        box.addLayout(form)
        self.secure_password=QCheckBox(self.t('Güvenilir parola kullan (en az 8 karakter)','Use a reliable password (at least 8 characters)'));self.secure_password.setChecked(True);box.addWidget(self.secure_password)
        self.password_note=self.label(self.t('Sudo işlemleri için parola koymak zorunludur. Bu seçenek açıkken en az 8 karakter; kapalıyken en az 1 karakter gerekir. Kullanıcı adında küçük harf kullan.','A password is mandatory for sudo. With this option enabled, use at least 8 characters; with it disabled, at least 1 character. Use lowercase letters for your username.'),'small');box.addWidget(self.password_note);box.addStretch()
    def summary_page(self):
        box=self.page(self.t('Son bir kontrol','One last look'),self.t('Kurulum başlamadan önce seçimlerini incele.','Review your choices before installation begins.'));self.summary=self.label('');self.summary.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse);box.addWidget(self.summary);box.addStretch()
    def install_page(self):
        box=self.page(self.t('Yeni sistem hazırlanıyor','Preparing your new system'),self.t('Kurulum adımları ve ilerleme burada görünür.','Follow the installation steps and progress here.'));box.itemAt(1).widget().hide();box.setContentsMargins(12,12,12,12);self.slide=SlideView();box.addWidget(self.slide,1)
        self.slide_title=self.label('','small');self.slide_body=self.label('','muted');box.addWidget(self.slide_title);box.addWidget(self.slide_body);progress_row=QHBoxLayout();self.phase=self.label(self.t('Kurulum bekleniyor','Waiting for installation'),'muted');self.percent=self.label('0%','muted');progress_row.addWidget(self.phase,1);progress_row.addWidget(self.percent);box.addLayout(progress_row);self.progress=QProgressBar();self.progress.setTextVisible(False);self.progress.setRange(0,100);self.progress.valueChanged.connect(lambda value:self.percent.setText(str(value)+'%'));box.addWidget(self.progress)
        self.terminal_toggle=QPushButton(self.t('Kurulum terminalini aç','Open installation terminal'));self.terminal_toggle.setCheckable(True);box.addWidget(self.terminal_toggle)
        self.terminal_window=QDialog(self,Qt.WindowType.Window);self.terminal_window.setWindowTitle(self.t('Dango Loader · Kurulum terminali','Dango Loader · Installation terminal'));self.terminal_window.setWindowIcon(self.windowIcon());self.terminal_window.resize(900,520);self.terminal_window.setMinimumSize(500,300)
        logs=QVBoxLayout(self.terminal_window);self.terminal=QPlainTextEdit();self.terminal.setReadOnly(True);self.terminal.document().setMaximumBlockCount(5000);logs.addWidget(self.terminal)
        self.terminal_toggle.toggled.connect(self.show_terminal);self.terminal_window.finished.connect(lambda _:self.terminal_toggle.setChecked(False));self.update_slide()
    def show_terminal(self,visible):
        if visible:self.terminal_window.show();self.terminal_window.raise_();self.terminal_window.activateWindow()
        else:self.terminal_window.hide()
    def finish_page(self):
        box=self.page(self.t('Her şey hazır','You are ready'),self.t('Yeni sistemin seni bekliyor.','Your new system is waiting for you.'));self.finish_note=self.label('','hero');box.addWidget(self.finish_note);box.addStretch();box.addWidget(self.button(self.t('Kapat','Close'),self.close,True))
    def scan(self):
        if self.busy or any(w.isRunning() for w in self.workers):return
        if hasattr(self,'process') and self.process.state()!=QProcess.ProcessState.NotRunning:return
        self.disk_confirm.setChecked(False)
        if self.demo:self.inventory=fixture();self.fill_devices();self.error_label.clear();return
        self.error_label.setText(self.t('Diskler algılanıyor…','Detecting disks…'))
        self.start_helper({'action':'scan'},True)
    def fill_devices(self):
        selected_disk=self.disk_combo.currentData();self.disk_combo.blockSignals(True);self.disk_combo.clear()
        disks=physical_disks(self.inventory)
        for disk in disks:self.disk_combo.addItem(f'{disk["path"]} · {int(disk["size"])/GIB:.1f} GiB · '+str(disk.get('model') or ''),disk['path'])
        if selected_disk and self.disk_combo.findData(selected_disk)>=0:self.disk_combo.setCurrentIndex(self.disk_combo.findData(selected_disk))
        self.disk_combo.blockSignals(False)
        self.detected_disks.setText(self.t('Algılanan disklerden kurulum diskini seç.','Select your installation disk from the detected disks.') if disks else self.t('Disk bulunamadı. Disk algılama ile yeniden dene.','No disks found. Try Detect disks again.'))
        self.fill_partitions()
    def selected_disk_changed(self,*args):
        self.error_label.clear();self.fill_partitions()
    def fill_partitions(self):
        selected=self.root_combo.currentData();selected_efi=self.efi_combo.currentData();self.root_combo.blockSignals(True);self.efi_combo.blockSignals(True);self.root_combo.clear();self.efi_combo.clear()
        disk=self.disk_combo.currentData();parts=[r for r in eligible_partitions(self.inventory) if r.get('disk')==disk]
        for row in parts:
            label=f'{row["path"]} · {int(row.get("size",0))/GIB:.1f} GiB · {row.get("fstype") or "—"}'
            if str(row.get('parttype','')).lower()=='21686148-6449-6e6f-744e-656564454649':continue
            if row.get('fstype') in ('vfat','fat','fat32'):self.efi_combo.addItem(label,row['path'])
            elif not self.alongside.isChecked() or row.get('fstype')=='ntfs':self.root_combo.addItem(label,row['path'])
        for combo,old in ((self.root_combo,selected),(self.efi_combo,selected_efi)):
            if old and combo.findData(old)>=0:combo.setCurrentIndex(combo.findData(old))
            combo.blockSignals(False)
        known=[s['name'] for s in self.inventory.get('systems',[]) if s.get('disk')==disk or s.get('device') in {r['path'] for r in parts}]
        self.systems_label.setText(self.t('Seçili disk: ','Selected disk: ')+str(disk or '—')+(' · '+', '.join(known) if known else ''))
        self.dualboot_button.setEnabled(any(r.get('fstype')=='ntfs' for r in parts));self.root_changed()
    def mode_changed(self):
        erase=self.erase.isChecked()
        self.disk_combo.setVisible(True);self.disk_label.setVisible(True)
        for widget in (self.root_combo,self.root_label):widget.setVisible(not erase)
        for widget in (self.efi_combo,self.efi_label):widget.setVisible(not erase and bool(self.inventory.get('uefi')))
        self.allocation.setVisible(self.alongside.isChecked());self.disk_confirm.setChecked(False)
        self.boot_note=self.t('UEFI: EFI bölümü kullanılır.','UEFI: an EFI partition is used.') if self.inventory.get('uefi') else self.t('BIOS: GPT diskte bios_grub bölümü gerekir; diski sil seçeneği bunu oluşturur.','BIOS: GPT needs a bios_grub partition; Erase disk creates it.')
        self.disk_warning.setText(self.boot_note+' '+self.t('Bu diskteki tüm dosyalar ve işletim sistemleri silinecek.','All files and operating systems on this disk will be erased.') if erase else self.t('Windows küçültülür; EFI korunur.','Windows will be resized; EFI is preserved.') if self.alongside.isChecked() else self.t('Seçili bölüm silinir; EFI korunur.','The selected partition is erased; EFI is preserved.'))
    def root_changed(self):
        self.ntfs_min=None;self.ntfs_device=None;self.disk_confirm.setChecked(False)
        row=next((r for r in self.inventory['devices'] if r['path']==self.root_combo.currentData()),None)
        if row:self.bar.total=max(1,int(row.get('size',0))//GIB);self.bar.maximum=max(30,self.bar.total-30);self.size.setMaximum(self.bar.maximum);self.bar.update()
        self.limits_label.setText(self.t('Önce uygun alanı kontrol et; Windows için gereken alan korunacak.','Check available space first; the space Windows needs will be kept.'));self.mode_changed()
    def open_partition_manager(self):
        binary=shutil.which('partitionmanager')
        if not binary:self.error_label.setText(self.t('KDE Partition Manager live ISO’da kurulu değil.','KDE Partition Manager is not installed in this live ISO.'));return
        ok,_=QProcess.startDetached(binary,[])
        if not ok:self.error_label.setText(self.t('Bölüm yöneticisi açılamadı.','Could not open the partition manager.'))
        else:self.error_label.setText(self.t('Bölüm değişikliklerinden sonra Disk algılama düğmesine basın.','Select Detect disks after changing partitions.'))
    def check_limits(self):
        if self.demo:self.accept_limits(110*GIB,self.root_combo.currentData());return
        self.start_helper({'action':'limits','device':self.root_combo.currentData()},True)
    def accept_limits(self,minimum,device):
        if device!=self.root_combo.currentData():return
        row=next(r for r in self.inventory['devices'] if r['path']==device);maximum=int((int(row['size'])-minimum)/GIB)-1
        if maximum<30:self.error_label.setText(self.t('Yeni sistem için yeterli küçültülebilir alan yok.','Not enough safely resizable space for the new system.'));return
        self.ntfs_min=minimum;self.ntfs_device=device;self.bar.maximum=maximum;self.size.setMaximum(maximum);self.limits_label.setText(self.t(f'Windows için en az {minimum/GIB:.1f} GiB korunacak.',f'At least {minimum/GIB:.1f} GiB will remain for Windows.'))
    def plan(self):
        rows={r['path']:r for r in self.inventory['devices']};root=rows.get(self.root_combo.currentData(),{});efi=rows.get(self.efi_combo.currentData(),{})
        return {'language':self.lang,'timezone':self.zone.currentText(),'keyboard':self.keyboard.currentData(),'keyboard_variant':self.keyboard_variants.currentData() or '','mode':'erase' if self.erase.isChecked() else 'alongside' if self.alongside.isChecked() else 'manual','root_device':root.get('path'),'root_uuid':device_identity(root),'efi_device':efi.get('path'),'efi_uuid':device_identity(efi),'disk_device':self.disk_combo.currentData(),'disk_identity':disk_identity(rows.get(self.disk_combo.currentData(),{})),'erase_confirmed':self.disk_confirm.isChecked(),'root_gib':self.size.value(),'filesystem':self.fs.currentText().lower(),'swap':self.swap.currentData(),'fullname':self.fullname.text().strip(),'username':self.username.text().strip(),'hostname':self.hostname.text().strip(),'password':self.password.text(),'secure_password':self.secure_password.isChecked(),'format_confirmed':self.disk_confirm.isChecked(),'resize_confirmed':self.disk_confirm.isChecked()}
    def advance(self):
        self.error_label.clear()
        try:
            if self.step==0:validate_hardware(self.inventory,self.profile)
            if self.step==1:
                zone=Path('/usr/share/zoneinfo')/self.zone.currentText()
                if not zone.is_file() or not zone.resolve().is_relative_to(Path('/usr/share/zoneinfo').resolve()):raise ValueError(self.t('Geçerli bir saat dilimi seçin.','Choose a valid timezone.'))
            if self.step==3:
                if self.storage_stack.currentIndex()==0:raise ValueError(self.t('Bir kurulum yöntemi seç.','Choose an installation method.'))
                if self.storage_stack.currentIndex()==2:self.go(4);return
                if not self.erase.isChecked() and (not self.root_combo.currentData() or (self.inventory.get('uefi') and not self.efi_combo.currentData()) or not self.disk_confirm.isChecked()):raise ValueError(self.t('Bölümleri seçip değişiklikleri onaylayın.','Choose partitions and confirm the changes.'))
                if self.alongside.isChecked() and self.ntfs_device!=self.root_combo.currentData():raise ValueError(self.t('Önce Windows boş alanını kontrol edin.','Check Windows resize limits first.'))
                if not self.disk_confirm.isChecked() or (self.erase.isChecked() and not self.disk_combo.currentData()):raise ValueError(self.t('Diski seç ve silmeyi onayla.','Choose a disk and confirm erasing it.'))
                validate_storage(self.plan(),self.inventory,self.profile)
                self.storage_stack.setCurrentIndex(2);return
            if self.step==4:
                if self.password.text()!=self.confirm_password.text():raise ValueError(self.t('Parolalar eşleşmiyor.','Passwords do not match.'))
                validate_plan(self.plan(),self.inventory,self.profile)
            if self.step==5:self.start_install();return
            self.go(min(7,self.step+1))
        except Exception as error:self.error_label.setText(str(error))
    def previous(self):
        if not self.busy:
            if self.step==3 and self.storage_stack.currentIndex()>0:self.storage_stack.setCurrentIndex(self.storage_stack.currentIndex()-1);return
            self.go(max(0,self.step-1))
    def go(self,index,animate=True):
        if self.busy and index not in (6,7):return
        if self.running_animation:self.running_animation.stop();self.animation_target.setGraphicsEffect(None);self.running_animation.deleteLater();self.running_animation=None
        self.step=index;self.sidebar.setVisible(index!=6);self.pages.setCurrentIndex(index)
        for i,b in enumerate(self.steps):b.setProperty('current',i==index);b.setEnabled(i<=index and not self.busy);b.style().unpolish(b);b.style().polish(b)
        self.back.setEnabled(index>0 and index<6 and not self.busy);self.next.setEnabled(index<6 and not self.busy);self.next.setVisible(index<6);self.next.setText(self.t('Kurulumu başlat','Start installation') if index==5 else self.t('İleri','Next'))
        if index==5:
            d=public_plan(self.plan());self.summary.setText('\n\n'.join([self.t('Kurulum biçimi: ','Installation mode: ')+(self.t('Windows yanında','Alongside Windows') if d['mode']=='alongside' else self.t('Diski sil ve kur','Erase disk and install') if d['mode']=='erase' else self.t('Seçili bölüme','Selected partition')),self.t('Bölüm: ','Partition: ')+str(d['disk_device'] if d['mode']=='erase' else d['root_device']),self.t('Başlatma: ','Boot: ')+('UEFI · '+str(d['efi_device']) if self.inventory.get('uefi') else 'BIOS · GRUB i386-pc'),self.t('Dosya sistemi: ','Filesystem: ')+{'btrfs':'Btrfs','ext4':'Ext4','xfs':'XFS'}[d['filesystem']],self.t('Bölge / klavye: ','Location / keyboard: ')+d['timezone']+' / '+d['keyboard']+(' ('+d['keyboard_variant']+')' if d['keyboard_variant'] else ''),self.t('Kullanıcı: ','User: ')+d['username']+' · '+d['hostname'],self.t('Swap: ','Swap: ')+(self.t('Otomatik','Automatic') if d['swap']=='auto' else self.t('Kapalı','Off')),self.t('Değişiklik: ','Change: ')+(self.t('NTFS küçültülür, yeni sistem için alan oluşturulur.','NTFS is shrunk and a new root partition is created.') if d['mode']=='alongside' else self.t('Tüm disk silinir; başlatma ve sistem bölümleri oluşturulur.','Entire disk is erased; boot and root partitions are created.') if d['mode']=='erase' else self.t('Seçilen sistem bölümü biçimlendirilir.','The selected root partition is formatted.'))]))
        if animate and self.isVisible():
            target=self.pages.currentWidget().widget();effect=QGraphicsOpacityEffect(target);target.setGraphicsEffect(effect);a=QPropertyAnimation(effect,b'opacity',self);a.setDuration(220);a.setStartValue(.25);a.setEndValue(1);a.setEasingCurve(QEasingCurve.Type.OutCubic);self.running_animation=a;self.animation_target=target
            def done():
                if self.running_animation is a:target.setGraphicsEffect(None);self.running_animation=None
                a.deleteLater()
            a.finished.connect(done);a.start()
    def slide_files(self):
        folder=Path(self.brand['folder'])/'slides'
        if self.dark and (folder/'dark').is_dir():folder=folder/'dark'
        if (folder/self.lang).is_dir():folder=folder/self.lang
        files=[]
        for number in range(1,11):
            for ext in ('.png','.jpg','.jpeg','.webp'):
                file=folder/(str(number)+ext)
                if file.is_file() and file.resolve().is_relative_to(Path(self.brand['folder']).resolve()):
                    if not QPixmap(str(file)).isNull():files.append(file)
                    break
        return files
    def update_slide(self):
        files=self.slide_files();slides=self.brand['slides'];count=len(files) if files else len(slides);index=self.slide_index%count;info=slides[index%len(slides)]
        if files:
            self.slide.setStyleSheet('');self.slide.set_image(files[index]);self.slide_title.setText(self.t(f'Slayt {index+1} / {count}',f'Slide {index+1} / {count}'));self.slide_body.clear();self.slide_body.hide()
        else:self.slide_body.show();self.slide.setText(info.get('symbol','◈'));self.slide.setStyleSheet('font-size:110px;color:'+self.brand['accent']);self.slide_title.setText(text(info['title'],self.lang));self.slide_body.setText(text(info['body'],self.lang))
    def next_slide(self):self.slide_index+=1;self.update_slide()
    def start_install(self):
        data=self.plan();validate_plan(data,self.inventory,self.profile)
        if not self.demo and not self.profile.get('allow_real_install'):self.error_label.setText(self.t('Bu geliştirme profili önizlemeye açıktır. Gerçek kurulum, VM doğrulamasından sonra profil içinde etkinleştirilir.','This development profile is preview-only. Enable real installation in the profile after VM validation.'));return
        if not self.demo:
            answer=QMessageBox.question(self,self.t('Disk değişikliklerini onayla','Confirm disk changes'),self.summary.text(),QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
            if answer!=QMessageBox.StandardButton.Yes:return
        self.busy=True;self.go(6);self.slide_timer.start();self.progress.setValue(0);self.terminal.clear()
        if self.demo:
            self.demo_index=0;self.demo_timer=QTimer(self);self.demo_timer.timeout.connect(self.demo_tick);self.demo_timer.start(550)
        else:self.start_helper(dict(data,action='install'))
    def demo_tick(self):
        phases=['preflight','check_windows','format_root','copy_system','region','keyboard','create_user','swap','bootloader','cleanup','complete'];code=phases[self.demo_index];self.handle_event({'progress':round(self.demo_index/(len(phases)-1)*100),'message':code});self.demo_index+=1
        if self.demo_index==len(phases):self.demo_timer.stop();self.finish(True)
    def start_helper(self,data,probe=False):
        helper=Path('/usr/share/dango-loader/helper.py')
        if not helper.is_file() or (os.geteuid()!=0 and not shutil.which('pkexec')):self.error_label.setText(self.t('Kurulu helper/pkexec bulunamadı. Kaynaktan --demo ile önizleyin.','Installed helper/pkexec not found. Preview source with --demo.'));self.busy=False;return
        if hasattr(self,'process') and self.process.state()!=QProcess.ProcessState.NotRunning:return
        self.probe_request=probe;self.request_action=data.get('action');self.request_device=data.get('device');self.buffer=b'';self.process=QProcess(self);self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        payload=json.dumps(data).encode();self.process.started.connect(lambda:(self.process.write(payload),self.process.closeWriteChannel()))
        self.process.readyReadStandardOutput.connect(self.read_helper);self.process.finished.connect(self.helper_finished);self.process.errorOccurred.connect(lambda _:self.finish(False) if not probe else self.error_label.setText(self.t('Alan denetimi başlatılamadı.','Could not start resize check.')))
        self.process.start('/usr/bin/python3',['-I',str(helper)]) if os.geteuid()==0 else self.process.start('pkexec',[str(helper)])
    def read_helper(self):
        self.buffer+=bytes(self.process.readAllStandardOutput())
        while b'\n' in self.buffer:
            line,self.buffer=self.buffer.split(b'\n',1)
            try:self.handle_event(json.loads(line))
            except (ValueError,TypeError):self.terminal.appendPlainText(line.decode(errors='replace'))
    def handle_event(self,item):
        if 'inventory' in item:self.inventory=item['inventory'];self.fill_devices();self.error_label.clear();return
        if 'minimum' in item:self.accept_limits(item['minimum'],item['device']);return
        if 'error' in item:self.error_label.setText(item['error']);self.terminal.appendPlainText(item['error']);return
        if 'log' in item:self.terminal.appendPlainText(item['log']);return
        code=item.get('message','');labels={'erase_disk':('Disk silinip bölümler oluşturuluyor','Erasing disk and creating partitions'),'preflight':('Kurulum denetleniyor','Checking installation'),'check_windows':('Windows dosya sistemi denetleniyor','Checking Windows filesystem'),'shrink_windows':('Windows için alan ayrılıyor','Resizing Windows'),'format_root':('Dosya sistemi hazırlanıyor','Preparing filesystem'),'copy_system':('Sistem dosyaları kopyalanıyor','Copying system files'),'configure_system':('Sistem yapılandırılıyor','Configuring system'),'region':('Bölge ve saat ayarlanıyor','Setting region and timezone'),'keyboard':('Klavye düzeni ayarlanıyor','Setting keyboard layout'),'create_user':('Kullanıcı oluşturuluyor','Creating user'),'swap':('RAM’e göre swap hazırlanıyor','Configuring RAM-sized swap'),'grub_config_repaired':('GRUB ayarındaki eksik tırnak düzeltildi; yedek alındı','Repaired a missing GRUB configuration quote; backup saved'),'bootloader':('Önyükleyici hazırlanıyor','Installing bootloader'),'remove_installer':('Kurucu yeni sistemden kaldırılıyor','Removing installer from the new system'),'cleanup':('Kurulum tamamlanıyor','Finishing installation'),'complete':('Tamamlandı','Complete')}
        title=self.t(*labels.get(code,(code,code)));self.phase.setText(title);self.terminal.appendPlainText(title)
        if 'progress' in item:self.progress.setValue(int(item['progress']))
    def helper_finished(self,code,status):
        self.read_helper()
        if self.probe_request:
            if code:self.error_label.setText(self.t('Disk denetimi başarısız. Terminal ayrıntılarını incele.','Disk check failed. Review terminal details.'))
        else:self.finish(code==0 and self.progress.value()==100)
    def finish(self,success):
        self.busy=False;self.slide_timer.stop()
        if success:self.go(7);self.finish_note.setText(self.t('Önizleme tamamlandı. Diskler değiştirilmedi.','Preview complete. No disks were changed.') if self.demo else self.t('Kurulum tamamlandı. Bilgisayarı yeniden başlatabilirsiniz.','Installation complete. You can restart your computer.'));self.password.clear();self.confirm_password.clear()
        else:self.terminal_toggle.setChecked(True);self.error_label.setText(self.t('Kurulum tamamlanamadı. Terminal ayrıntılarını inceleyin.','Installation did not complete. Review terminal details.'))
    def system_theme_changed(self,*args):
        if self.theme_choice.currentData()=='system':self.skin()
    def changeEvent(self,event):
        super().changeEvent(event)
        if event.type()==QEvent.Type.ApplicationPaletteChange and hasattr(self,'theme_choice'):
            self.system_dark=QApplication.palette().color(QPalette.ColorRole.Window).lightness()<128
            self.system_theme_changed()
    def closeEvent(self,event):
        if self.busy or any(w.isRunning() for w in self.workers):event.ignore();return
        if hasattr(self,'process') and self.process.state()!=QProcess.ProcessState.NotRunning:event.ignore();return
        self.terminal_window.close();self.slide_timer.stop();self.keyboard_timer.stop();super().closeEvent(event)
