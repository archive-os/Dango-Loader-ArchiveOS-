"""Privileged installation engine. Uses argv, preflight checks and strict exit codes."""
import json,os,shutil,stat,subprocess,tempfile,time,shlex
from pathlib import Path
from . import storage
from .model import validate_plan
from .i18n import locale_for

def event(progress,message):print(json.dumps({'progress':progress,'message':message}),flush=True)

def run(argv,secret=None,answer=None):
    print(json.dumps({'log':shlex.join(argv)}),flush=True)
    result=subprocess.run(argv,input=secret if secret is not None else answer,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=dict(os.environ,LC_ALL='C',LANG='C'),check=False)
    if result.returncode:raise RuntimeError(Path(argv[0]).name+' failed: '+(result.stdout[-1200:] if secret is None else 'private input command failed'))
    if secret is None and argv[0] not in ('openssl','blkid') and not (argv[0]=='unsquashfs' and '-ls' in argv) and argv[0]!='ntfsls' and result.stdout.strip():
        print(json.dumps({'log':result.stdout[-4096:]}),flush=True)
    return result.stdout

def trusted(path):
    path=Path(path).resolve(strict=True)
    for part in [path,*path.parents]:
        info=part.stat()
        if info.st_uid!=0 or info.st_mode&0o022:raise PermissionError('Installed code/config must be root-owned and not writable by others: '+str(part))
    return path

def trusted_source(path):
    source=Path(path).resolve(strict=True)
    if not source.is_file():raise ValueError('Source image is not a regular file')
    try:return trusted(source)
    except PermissionError as ownership_error:
        # ISO9660/SquashFS permissions can retain arbitrary creator ownership.
        # The kernel read-only mount, not its archived mode bits, protects the source.
        try:
            report=json.loads(storage.capture(['findmnt','--json','--target',str(source),'--output','TARGET,FSTYPE,OPTIONS']))
            rows=report.get('filesystems',[])
            if len(rows)!=1:raise ValueError('Source mount is ambiguous')
            mount=rows[0];point=Path(mount['target']).resolve(strict=True)
            options=set(mount.get('options','').split(','))
            if mount.get('fstype') not in ('iso9660','squashfs') or 'ro' not in options:raise ValueError('Source is not on read-only ISO9660/SquashFS media')
            if not source.is_relative_to(point):raise ValueError('Source is outside its verified mount')
            # Protect the mount attachment against replacement through writable parents.
            if point!=Path('/'):trusted(point.parent)
            return source
        except (OSError,ValueError,KeyError,subprocess.SubprocessError) as error:
            raise PermissionError('Installation source must be protected or on read-only ISO media: '+str(source)+'; '+str(error)) from ownership_error

def target_path(root,relative):
    path=Path(root)/relative;resolved=path.resolve()
    if not resolved.is_relative_to(Path(root).resolve()):raise ValueError('Target path escapes installed root: '+relative)
    return path

def write(root,relative,content,mode=0o644):
    path=target_path(root,relative);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content);path.chmod(mode)

def ram_mib():
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemTotal:'):return int(line.split()[1])//1024
    return 4096

def swap_mib(ram):return max(512,min(8192,ram if ram<=4096 else ram//2))

def setup_swap(root):
    # Calculate at boot so this installed image also adapts to later RAM upgrades.
    program='''#!/usr/bin/python3
import pathlib,subprocess
mem=int(next(l for l in pathlib.Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemTotal:')).split()[1])//1024
size=max(512,min(8192,mem if mem<=4096 else mem//2))
def run(args):return subprocess.check_output(args,text=True).strip()
if any('/dev/zram' in line for line in pathlib.Path('/proc/swaps').read_text().splitlines()[1:]):raise SystemExit(0)
subprocess.run(['modprobe','zram'],check=True)
try:device=run(['zramctl','--find','--size',str(size)+'M','--algorithm','zstd'])
except subprocess.CalledProcessError:device=run(['zramctl','--find','--size',str(size)+'M'])
subprocess.run(['mkswap',device],check=True)
subprocess.run(['swapon','--priority','100',device],check=True)
'''
    write(root,'usr/lib/dango-loader/zram-setup.py',program,0o755)
    write(root,'etc/systemd/system/dango-zram.service','''[Unit]
Description=RAM-sized compressed swap configured by Dango Loader
After=systemd-modules-load.service
Before=multi-user.target
[Service]
Type=oneshot
ExecStart=/usr/bin/python3 -I /usr/lib/dango-loader/zram-setup.py
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
''')
    write(root,'etc/sysctl.d/90-dango-swap.conf','vm.swappiness=80\n')
    wants=target_path(root,'etc/systemd/system/multi-user.target.wants');wants.mkdir(parents=True,exist_ok=True)
    link=wants/'dango-zram.service'
    if link.is_symlink() or link.exists():link.unlink()
    link.symlink_to('../dango-zram.service')

def remove_installer(root,chroot):
    """Remove only this installer in the mounted target, leaving the live app running."""
    status=target_path(root,'var/lib/dpkg/status')
    installed=False
    if status.is_file():
        for paragraph in status.read_text().split('\n\n'):
            if 'Package: dango-loader' in paragraph.splitlines() and 'Status: install ok installed' in paragraph.splitlines():installed=True
    if installed:run(chroot+['dpkg','--purge','dango-loader'])
    # Also clean manual ISO integration and any inherited desktop copies.
    paths=['usr/bin/dango-loader','usr/share/dango-loader','etc/dango-loader','usr/share/applications/dango-loader.desktop','usr/share/icons/hicolor/256x256/apps/dango-loader.png','usr/share/polkit-1/actions/org.archiveos.dango-loader.policy','usr/share/polkit-1/actions/org.archiveos.dango-loader.launch.policy','etc/xdg/autostart/dango-loader-live.desktop']
    for relative in paths:
        path=target_path(root,relative)
        if path.is_symlink() or path.is_file():path.unlink()
        elif path.is_dir():shutil.rmtree(path)
    for parent in ('etc/skel','home'):
        directory=target_path(root,parent)
        if directory.is_dir():
            for shortcut in directory.rglob('dango-loader.desktop'):
                if shortcut.is_symlink():shortcut.unlink()
                else:
                    target_path(root,str(shortcut.relative_to(root))).unlink()

def checked_grub_config(content,label='etc/default/grub'):
    """Parse only; never source a live-image shell configuration."""
    def check(text):
        result=subprocess.run(['/bin/sh','-n'],input=text,text=True,capture_output=True)
        return result.returncode==0,result.stderr.strip()
    valid,error=check(content)
    if valid:return content
    import re
    lines=content.splitlines(keepends=True);changed=False
    for index,line in enumerate(lines):
        match=re.fullmatch(r'(\s*GRUB_DISTRIBUTOR\s*=\s*)([\"\'])([\w .+\-]+)\s*',line.rstrip('\n'))
        if match:
            lines[index]=match[1]+match[2]+match[3].rstrip()+match[2]+('\n' if line.endswith('\n') else '')
            changed=True
    fixed=''.join(lines);valid,error=check(fixed)
    if not changed or not valid:raise ValueError('Invalid GRUB shell configuration '+label+': '+error)
    return fixed

def prepare_grub_config(target):
    config=target_path(target,'etc/default/grub')
    if config.is_file():
        original=config.read_text();fixed=checked_grub_config(original)
        if original!=fixed:
            backup=target_path(target,'etc/default/grub.dango-backup')
            if backup.exists():raise ValueError('GRUB backup already exists; inspect it before retrying')
            write(target,'etc/default/grub.dango-backup',original)
            write(target,'etc/default/grub',fixed)
            event(80,'grub_config_repaired')
    folder=target_path(target,'etc/default/grub.d')
    if folder.is_dir():
        for path in sorted(folder.glob('*.cfg')):
            checked=target_path(target,str(path.relative_to(target)))
            text=checked.read_text()
            if checked_grub_config(text,str(path.relative_to(target)))!=text:
                raise ValueError('Invalid GRUB override; repair it in the source image: '+str(path.relative_to(target)))

def preflight(data,profile,inventory=None):
    if os.geteuid()!=0:raise PermissionError('Installation needs administrator privileges')
    if profile.get('allow_real_install') is not True:raise PermissionError('Real installation is disabled in this development profile; validate it in a VM first')
    source=trusted_source(profile['source_image'])
    with source.open('rb') as stream:magic=stream.read(4)
    if magic!=b'hsqs':raise ValueError('Source is not a SquashFS image')
    inventory=inventory or storage.discover();root,efi=validate_plan(data,inventory,profile)
    if data.get('filesystem') not in ('ext4','btrfs','xfs'):raise ValueError('Unsupported filesystem')
    root_partition_name(profile)
    if data.get('swap') not in ('auto','off'):raise ValueError('Unsupported swap policy')
    for device in ([root['path']] if data['mode']=='erase' else [root['path']]+([efi['path']] if efi else [])):
        if not stat.S_ISBLK(Path(device).stat().st_mode):raise ValueError('Target is not a block device')
    required=['unsquashfs','mount','umount','blkid','chroot','openssl','udevadm','mkfs.'+data['filesystem']]
    if data['mode']=='erase':required+=['parted']+(['mkfs.vfat'] if inventory.get('uefi') else [])
    if data['mode']=='alongside':required+=['ntfsresize','ntfsls','parted','sfdisk','blockdev']
    if data['filesystem']=='btrfs':required+=['btrfs']
    for tool in required:
        if not shutil.which(tool):raise FileNotFoundError('Required tool is missing: '+tool)
    listing=run(['unsquashfs','-ls',str(source)])
    for token in ('etc/passwd','boot/vmlinuz','usr/sbin/grub-install','usr/sbin/update-initramfs','usr/sbin/update-grub'):
        if token not in listing:raise ValueError('Live image is missing '+token)
    if data['mode']=='alongside' and 'usr/bin/os-prober' not in listing:raise ValueError('Live image needs os-prober for dual boot')
    if 'etc/default/grub' in listing:checked_grub_config(run(['unsquashfs','-cat',str(source),'etc/default/grub']))
    target_release=run(['unsquashfs','-cat',str(source),'etc/os-release'])
    if not any(value in target_release for value in ('ID=ubuntu','ID=debian','ID_LIKE=debian','ID_LIKE="debian"')):raise ValueError('Choose a supported Debian-family live image')
    grub_platform='x86_64-efi' if inventory.get('uefi') else 'i386-pc'
    if 'usr/lib/grub/'+grub_platform+'/modinfo.sh' not in listing:raise ValueError('Live image is missing GRUB modules for '+grub_platform+'; install grub-pc-bin and grub-efi-amd64-bin inside the image')
    if not inventory.get('uefi') and data['mode']!='erase':
        table=next(r for r in inventory['devices'] if r['path']==root['disk'])
        if table.get('pttype') in ('dos','msdos'):
            starts=[storage.geometry(root['disk'],r['path'])[1] for r in inventory['devices'] if r.get('type')=='part' and r.get('disk')==root['disk']]
            if not starts or min(starts)<storage.MIB:raise ValueError('BIOS/MBR installation needs at least 1 MiB before the first partition for GRUB embedding')
    return root,efi

def root_partition_name(profile):
    name=profile.get('root_partition_name') or ('DangoRoot / '+profile.get('bootloader_id','Linux'))
    if not isinstance(name,str) or not name.strip() or len(name)>36 or any(ord(c)<32 or ord(c) in (34,39,92) for c in name):raise ValueError('Invalid root partition name')
    return name

def root_filesystem_label(profile,filesystem):
    name=root_partition_name(profile);limit={'ext4':16,'xfs':12,'btrfs':255}[filesystem]
    if len(name.encode('utf-8'))>limit:name=profile.get('bootloader_id','Linux')
    return name.encode('utf-8')[:limit].decode('utf-8',errors='ignore') or 'Linux'

def execute(data,profile):
    event(0,'preflight');root,efi=preflight(data,profile)
    boot_uefi=storage.discover().get('uefi',False)
    name=root_partition_name(profile)
    device=root['path'];disk=root['disk'];mounts=[];target=Path(tempfile.mkdtemp(prefix='dango-target-',dir='/mnt'))
    try:
        if data['mode']=='erase':
            validate_plan(data,storage.discover(),profile)
            event(5,'erase_disk')
            run(['parted','--script',disk,'mklabel','gpt'])
            if boot_uefi:
                run(['parted','--script',disk,'mkpart','DangoEFI','fat32','1MiB','513MiB'])
                run(['parted','--script',disk,'set','1','esp','on'])
                root_start='513MiB'
            else:
                run(['parted','--script',disk,'mkpart','DangoBIOS','1MiB','3MiB'])
                run(['parted','--script',disk,'set','1','bios_grub','on'])
                root_start='3MiB'
            run(['parted','--script',disk,'mkpart',json.dumps(name,ensure_ascii=False),data['filesystem'],root_start,'100%'])
            run(['udevadm','settle'])
            parts=[r for r in storage.discover()['devices'] if r.get('type')=='part' and r.get('disk')==disk]
            if len(parts)!=2:raise RuntimeError('Could not verify the two new partitions')
            parts.sort(key=lambda r:int(__import__('re').search(r'(\d+)$',r['path'])[1]))
            boot,root=parts;device=root['path']
            if boot_uefi:
                efi=boot
                run(['mkfs.vfat','-F','32',efi['path']]);efi=dict(efi,uuid=run(['blkid','-s','UUID','-o','value',efi['path']]).strip())
                if not efi['uuid']:raise RuntimeError('New EFI UUID is unavailable')
            else:
                efi=None
                if str(boot.get('parttype','')).lower()!=storage.BIOS_GRUB_GUID:raise RuntimeError('New BIOS boot partition type could not be verified')
        elif data['mode']=='alongside':
            event(5,'check_windows')
            if not run(['ntfsls','-p','/Windows/System32',device]).strip():raise ValueError('This NTFS volume is not a Windows installation')
            minimum=storage.ntfs_limits(device);number,start,end=storage.geometry(disk,device)
            layout=storage.alongside_layout(start,end,data['root_gib'],minimum)
            run(['ntfsresize','--no-action','--size',str(layout['windows_bytes']),device])
            # Re-read identity/mount state immediately before the first destructive operation.
            validate_plan(data,storage.discover(),profile)
            sector=int(run(['blockdev','--getss',disk]).strip())
            if sector not in (512,4096) or layout['windows_bytes']%sector:raise ValueError('Unsupported sector geometry')
            resize=['sfdisk','--lock','--wipe','never','--wipe-partitions','never','-N',str(number),disk]
            specification='size='+str(layout['windows_bytes']//sector)+'\n'
            run(resize+['--no-act'],answer=specification)
            event(10,'shrink_windows');run(['ntfsresize','--size',str(layout['windows_bytes']),device],answer='y\n')
            run(resize,answer=specification)
            _,new_start,new_end=storage.geometry(disk,device)
            if new_start!=start or new_end!=layout['windows_end']:raise RuntimeError('Partition resize geometry differs from the confirmed plan')
            before={r['path'] for r in storage.discover()['devices']}
            table=next(r for r in storage.discover()['devices'] if r['path']==disk)
            label=name if table.get('pttype')=='gpt' else 'primary'
            run(['parted','--script',disk,'unit','B','mkpart',json.dumps(label,ensure_ascii=False),data['filesystem'],str(layout['root_start'])+'B',str(layout['root_end'])+'B'])
            run(['udevadm','settle'])
            created=[r for r in storage.discover()['devices'] if r['path'] not in before and r.get('disk')==disk and r.get('type')=='part']
            if len(created)!=1:raise RuntimeError('Could not uniquely identify new root partition')
            device=created[0]['path']
        else:validate_plan(data,storage.discover(),profile)
        event(18,'format_root')
        args={'ext4':['mkfs.ext4','-F'], 'btrfs':['mkfs.btrfs','-f'], 'xfs':['mkfs.xfs','-f']}[data['filesystem']]
        run(args+['-L',root_filesystem_label(profile,data['filesystem']),device]);run(['mount',device,str(target)]);mounts.append(target)
        if data['filesystem']=='btrfs':
            run(['btrfs','subvolume','create',str(target/'@')]);run(['btrfs','subvolume','create',str(target/'@home')])
            run(['umount',str(target)]);mounts.pop();run(['mount','-o','subvol=@,compress=zstd:3',device,str(target)]);mounts.append(target)
        if data['filesystem']=='btrfs':
            home=target_path(target,'home');home.mkdir(exist_ok=True);run(['mount','-o','subvol=@home,compress=zstd:3',device,str(home)]);mounts.append(home)
        event(25,'copy_system');run(['unsquashfs','-strict-errors','-no-progress','-force','-d',str(target),profile['source_image']])
        event(65,'configure_system')
        if boot_uefi:
            efi_path=target_path(target,'boot/efi');efi_path.mkdir(parents=True,exist_ok=True);run(['mount',efi['path'],str(efi_path)]);mounts.append(efi_path)
        root_uuid=run(['blkid','-s','UUID','-o','value',device]).strip()
        if not root_uuid:raise ValueError('Root filesystem UUID is unavailable')
        options='defaults,subvol=@,compress=zstd:3' if data['filesystem']=='btrfs' else 'defaults'
        fstab=f'UUID={root_uuid} / {data["filesystem"]} {options} 0 '+('1' if data['filesystem']=='ext4' else '0')+'\n'
        if data['filesystem']=='btrfs':fstab+=f'UUID={root_uuid} /home btrfs defaults,subvol=@home,compress=zstd:3 0 0\n'
        if boot_uefi:fstab+=f'UUID={efi["uuid"]} /boot/efi vfat umask=0077 0 2\n'
        write(target,'etc/fstab',fstab)
        write(target,'etc/hostname',data['hostname']+'\n');write(target,'etc/hosts','127.0.0.1 localhost\n127.0.1.1 '+data['hostname']+'\n::1 localhost ip6-localhost\n')
        event(67,'region');write(target,'etc/timezone',data['timezone']+'\n')
        local=target/'etc/localtime'
        if local.is_symlink() or local.exists():local.unlink()
        local.symlink_to('/usr/share/zoneinfo/'+data['timezone'])
        event(69,'keyboard')
        keyboard='tr' if data['keyboard']=='tr-f' else data['keyboard'];variant='f' if data['keyboard']=='tr-f' else data.get('keyboard_variant','')
        write(target,'etc/default/keyboard',f'XKBMODEL="pc105"\nXKBLAYOUT="{keyboard}"\nXKBVARIANT="{variant}"\nXKBOPTIONS=""\n')
        locale=locale_for(data['language']);write(target,'etc/default/locale','LANG='+locale+'\n')
        for sub in ('dev','proc','sys','run'):
            path=target_path(target,sub);path.mkdir(exist_ok=True);run(['mount','--rbind','/'+sub,str(path)]);mounts.append(path);run(['mount','--make-rslave',str(path)])
        chroot=['chroot',str(target)]
        event(72,'create_user')
        passwd=target_path(target,'etc/passwd').read_text()
        for user in profile.get('live_users',[]):
            if user in ('root','daemon','nobody') or not isinstance(user,str):raise ValueError('Invalid live-user removal configuration')
            if any(line.startswith(user+':') and line.split(':')[2]!='0' for line in passwd.splitlines()):run(chroot+['userdel','--remove',user])
        run(chroot+['useradd','--create-home','--shell','/bin/bash','--comment',data['fullname'],'--groups',','.join(profile.get('admin_groups',['sudo'])),data['username']])
        hash_=run(['openssl','passwd','-6','-stdin'],data['password']+'\n').strip()
        run(chroot+['chpasswd','--encrypted'],data['username']+':'+hash_+'\n');data['password']=''
        run(chroot+['passwd','--lock','root'])
        write(target,'etc/sddm.conf.d/99-dango-login.conf','[Autologin]\nUser=\nSession=\n')
        write(target,'etc/machine-id','');machine=target/'var/lib/dbus/machine-id'
        if machine.exists() and not machine.is_symlink():machine.unlink()
        event(77,'swap')
        if data['swap']=='auto':setup_swap(target)
        prepare_grub_config(target)
        event(80,'bootloader')
        write(target,'etc/default/grub.d/40-dango-os-prober.cfg','GRUB_DISABLE_OS_PROBER=false\n')
        run(chroot+['locale-gen',locale]);run(chroot+['update-initramfs','-u','-k','all'])
        if boot_uefi:
            run(chroot+['grub-install','--target=x86_64-efi','--efi-directory=/boot/efi','--bootloader-id='+profile['bootloader_id'],'--recheck'])
        else:run(chroot+['grub-install','--target=i386-pc','--recheck',disk])
        run(chroot+['update-grub']);event(93,'remove_installer');remove_installer(target,chroot);event(95,'cleanup');run(['sync'])
    finally:
        cleanup=[]
        for mount in reversed(mounts):
            try:run(['umount','--recursive',str(mount)])
            except Exception as error:cleanup.append(str(error))
        if not cleanup:
            try:target.rmdir()
            except OSError:pass
        elif not __import__('sys').exc_info()[0]:raise RuntimeError('Unmount failed: '+'; '.join(cleanup))
    event(100,'complete')
