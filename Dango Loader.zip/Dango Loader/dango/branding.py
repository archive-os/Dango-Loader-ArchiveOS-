import json,re,os
from pathlib import Path

def language():
    for key in ('LC_ALL','LANGUAGE','LC_MESSAGES','LANG'):
        value=os.environ.get(key,'').split(':')[0]
        if value:
            from .i18n import languages
            code=value.split('.')[0];choices=languages()
            if code.startswith('tr'):return 'tr'
            if code in choices:return code
            short=code.split('_')[0]
            return short if short in choices else next((x for x in choices if x.split('_')[0]==short),'en')
    return 'en'

def text(value,lang):
    return value.get(lang,value.get('en','')) if isinstance(value,dict) else str(value)

def load_branding(folder):
    folder=Path(folder).resolve();file=folder/'branding.json'
    if file.stat().st_size>128*1024:raise ValueError('Branding file is too large')
    data=json.loads(file.read_text())
    for key in ('accent','background'):
        if not re.fullmatch(r'#[0-9a-fA-F]{6}',data.get(key,'')):raise ValueError('Invalid '+key+'; use #RRGGBB')
    logo=(folder/data.get('logo','')).resolve()
    if not logo.is_relative_to(folder) or not logo.is_file():raise ValueError('Logo must be a file inside branding/')
    if not data.get('name') or not isinstance(data.get('slides'),list) or not 1<=len(data['slides'])<=20:raise ValueError('Branding needs a name and 1–20 slides')
    data['folder']=str(folder);data['logo_path']=str(logo)
    data['slides_interval_ms']=max(1500,min(60000,int(data.get('slides_interval_ms',5500))))
    return data
