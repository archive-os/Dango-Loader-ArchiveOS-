import json,re
from pathlib import Path
from functools import lru_cache
BASE=Path(__file__).resolve().parents[1]
@lru_cache(maxsize=None)
def catalog(code):
    path=BASE/'translations'/(code+'.json')
    return json.loads(path.read_text()) if re.fullmatch(r'[a-z]{2,3}(?:[_@][A-Za-z0-9_-]+)?',code) and path.is_file() else {}
def languages():return sorted({'en','tr'}|{p.stem for p in (BASE/'translations').glob('*.json')})
def locale_for(code):
    lines=Path('/usr/share/i18n/SUPPORTED').read_text().splitlines() if Path('/usr/share/i18n/SUPPORTED').exists() else []
    choices=[line.split()[0] for line in lines if len(line.split())>1 and line.split()[1]=='UTF-8']
    if code=='en':return 'en_US.UTF-8'
    exact=next((x for x in choices if x.split('.')[0]==code),None)
    return exact or next((x for x in choices if x.split('_')[0]==code.split('_')[0] and '@' not in x),'en_US.UTF-8')
def translate(code,en,tr=None):
    if code.startswith('tr') and tr is not None:return tr
    table=catalog(code)
    aliases={'Next':'Next','Back':'Back','Start installation':'Install','Finish':'Finish','Storage':'Partitions','User':'Users','Welcome!':'Welcome','Choose your keyboard':'Keyboard','Where are you based?':'Location','One last look':'Summary','Preparing your new system':'Install','You are ready':'Finish','Erase disk and install':'Erase disk','Advanced partition management':'Manual partitioning','Filesystem':'File System','Username':'Username:','Full name':'Full Name:','Password':'Password:','Confirm password':'Repeat Password:','Computer name':'Computer Name:','Timezone':'Time Zone','Installer appearance':'Theme','Installation mode: ':'Partitioning: '}
    source=aliases.get(en,en);return table.get(en,table.get(source,en))
