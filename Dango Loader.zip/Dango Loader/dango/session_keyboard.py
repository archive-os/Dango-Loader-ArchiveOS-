import os,shutil,subprocess,pwd
from .keyboards import keyboard_catalog

def apply_keyboard(layout,variant='',demo=False):
    catalog=keyboard_catalog()
    if layout not in catalog or variant not in catalog[layout]['variants']:raise ValueError('Unknown keyboard layout or variant')
    if demo:return 'preview'
    prefix=[];session_env=dict(os.environ)
    uid=os.environ.get('PKEXEC_UID') or os.environ.get('SUDO_UID')
    if os.geteuid()==0 and uid and uid.isdigit() and int(uid)!=0:
        user=pwd.getpwuid(int(uid));prefix=['/usr/sbin/runuser','-u',user.pw_name,'--']
        session_env.update(HOME=user.pw_dir,XDG_CONFIG_HOME=user.pw_dir+'/.config',XDG_RUNTIME_DIR='/run/user/'+uid,DBUS_SESSION_BUS_ADDRESS='unix:path=/run/user/'+uid+'/bus')
        session_env.setdefault('XDG_CURRENT_DESKTOP','KDE')
    if session_env.get('WAYLAND_DISPLAY') or 'kde' in session_env.get('XDG_CURRENT_DESKTOP','').lower():
        tool=shutil.which('kwriteconfig6')
        if not tool:raise RuntimeError('kwriteconfig6 is required for a Plasma keyboard change')
        for key,value in [('Use','true'),('Model','pc105'),('SwitchMode','Global'),('LayoutList',layout),('VariantList',variant)]:
            args=[tool,'--file','kxkbrc','--group','Layout','--key',key]
            if key=='VariantList':args+=['--notify']
            result=subprocess.run(prefix+args+[value],env=session_env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=8)
            if result.returncode:raise RuntimeError(result.stderr.strip() or 'Could not apply keyboard layout')
        return 'plasma'
    if os.environ.get('DISPLAY') and shutil.which('setxkbmap'):
        subprocess.run(prefix+['setxkbmap','-layout',layout,'-variant',variant],env=session_env,check=True,timeout=8);return 'x11'
    raise RuntimeError('No supported graphical keyboard session is available')
