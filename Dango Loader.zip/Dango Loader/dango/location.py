"""Read-only timezone points, world outlines and XKB keyboard choices."""
import json,math,re
from functools import lru_cache
from pathlib import Path
from xml.etree import ElementTree
from PyQt6.QtCore import Qt,pyqtSignal,QPointF,QRectF
from PyQt6.QtGui import QPainter,QColor,QPen,QPolygonF
from PyQt6.QtWidgets import QWidget,QSizePolicy,QToolTip

def timezone_points():
    points=[];file=Path('/usr/share/zoneinfo/zone.tab')
    if not file.exists():return points
    def angle(value):
        sign=-1 if value[0]=='-' else 1;digits=value[1:];degree=2 if len(digits) in (4,6) else 3
        return sign*(int(digits[:degree])+int(digits[degree:degree+2])/60+(int(digits[degree+2:])/3600 if len(digits)>degree+2 else 0))
    for line in file.read_text().splitlines():
        if not line or line.startswith('#'):continue
        cols=line.split('\t');m=re.fullmatch(r'([+-]\d+)([+-]\d+)',cols[1])
        if m:points.append((cols[2],angle(m[1]),angle(m[2])))
    return points


class TimezoneMap(QWidget):
    selected=pyqtSignal(str)
    def __init__(self,world_file,accent,parent=None):
        super().__init__(parent);self.points=timezone_points();self.zone='UTC';self.dark=False;self.accent=QColor(accent);self.polygons=[]
        self.setMinimumHeight(220);self.setMaximumHeight(310);self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding);self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if Path(world_file).is_file():
            for feature in json.loads(Path(world_file).read_text())['features']:
                geometry=feature['geometry'];parts=geometry['coordinates'] if geometry['type']=='MultiPolygon' else [geometry['coordinates']]
                self.polygons.extend(part[0] for part in parts if part)
    def set_zone(self,zone):self.zone=zone;self.update()
    def project(self,lat,lon):
        return QPointF(12+(lon+180)/360*max(1,self.width()-24),12+(82-lat)/142*max(1,self.height()-24))
    def nearest(self,position):
        return min(self.points,key=lambda p:(self.project(p[1],p[2]).x()-position.x())**2+(self.project(p[1],p[2]).y()-position.y())**2) if self.points else None
    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            point=self.nearest(event.position())
            if point:self.set_zone(point[0]);self.selected.emit(point[0])
    def mouseMoveEvent(self,event):
        point=self.nearest(event.position())
        if point:QToolTip.showText(event.globalPosition().toPoint(),point[0].replace('_',' '),self)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#213340' if self.dark else '#edf7fd'));p.drawRoundedRect(QRectF(self.rect()),12,12)
        p.setClipRect(QRectF(8,8,self.width()-16,self.height()-16));p.setPen(QPen(QColor('#52738a' if self.dark else '#b8d5e7'),.6));p.setBrush(QColor('#365267' if self.dark else '#d3e8f4'))
        for coords in self.polygons:
            if max(c[1] for c in coords)<-60:continue
            p.drawPolygon(QPolygonF([self.project(lat,lon) for lon,lat in coords]))
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#9ecae3' if self.dark else '#6794ae'))
        for zone,lat,lon in self.points:p.drawEllipse(self.project(lat,lon),1.8,1.8)
        selected=next((point for point in self.points if point[0]==self.zone),None)
        if selected:
            center=self.project(selected[1],selected[2]);p.setBrush(QColor('#ffffff'));p.drawEllipse(center,8,8);p.setBrush(QColor('#167dae'));p.drawEllipse(center,5,5)
