"""Create the desktop installer shortcut only in an actual live session."""
import os,re,shutil,subprocess,fcntl
from pathlib import Path

def is_live(cmdline=None,markers=None):
    if cmdline is None:
        try:cmdline=Path('/proc/cmdline').read_text()
        except OSError:cmdline=''
    if markers is None:markers=any(Path(p).exists() for p in ('/run/casper','/run/live/medium','/lib/live/mount/medium'))
    return bool(re.search(r'(?:^|\s)(?:boot=(?:casper|live)(?:\s|$)|root=live:)',cmdline)) or bool(markers)

def desktop_shortcut(home,desktop,source,live):
    if not live:return None
    home=Path(home).resolve();desktop=Path(desktop)
    if not desktop.resolve().is_relative_to(home):raise ValueError('Desktop must be inside this live user home')
    desktop.mkdir(parents=True,exist_ok=True);destination=desktop/'dango-loader.desktop'
    if destination.is_symlink():raise ValueError('Installer shortcut must not be a symlink')
    shutil.copyfile(source,destination);destination.chmod(0o755);return destination

def launch_live(runtime,launcher='/usr/bin/dango-loader'):
    """The session lock is held until the installer closes; duplicate starters exit."""
    if not (os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')):return False
    runtime=Path(runtime)
    if not runtime.is_dir() or runtime.stat().st_uid!=os.getuid():return False
    descriptor=os.open(runtime/'dango-loader-live.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    try:
        try:fcntl.flock(descriptor,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return False
        result=subprocess.run([launcher],check=False)
        if result.returncode:raise RuntimeError('Dango Loader live startup failed: '+str(result.returncode))
        return True
    finally:os.close(descriptor)

def main():
    if not is_live():return
    home=Path.home();desktop=home/'Desktop'
    if shutil.which('xdg-user-dir'):
        result=subprocess.run(['xdg-user-dir','DESKTOP'],text=True,stdout=subprocess.PIPE,check=False)
        if result.returncode==0 and result.stdout.strip():desktop=Path(result.stdout.strip())
    destination=desktop_shortcut(home,desktop,'/usr/share/applications/dango-loader.desktop',True)
    if destination and shutil.which('gio'):subprocess.run(['gio','set',str(destination),'metadata::trusted','true'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
    runtime=os.environ.get('XDG_RUNTIME_DIR')
    if runtime:launch_live(runtime)
