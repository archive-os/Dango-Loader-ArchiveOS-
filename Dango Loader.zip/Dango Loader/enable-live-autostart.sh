#!/bin/sh
set -eu
if [ "$(id -u)" -ne 0 ]; then echo 'Run inside the ISO chroot as root.' >&2; exit 1; fi
[ -f /usr/share/dango-loader/live-desktop.py ]
install -d -m 755 /etc/xdg/autostart
cat > /etc/xdg/autostart/dango-loader-live.desktop <<'ENTRY'
[Desktop Entry]
Type=Application
Name=Dango Loader (Live)
Exec=/usr/bin/python3 -I /usr/share/dango-loader/live-desktop.py
Icon=dango-loader
NoDisplay=true
X-GNOME-Autostart-enabled=true
ENTRY
printf '%s\n' 'Live-only startup enabled for the next desktop login.'
