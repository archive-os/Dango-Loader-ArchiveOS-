#!/usr/bin/python3
import argparse,sys
from pathlib import Path
from PyQt6.QtWidgets import QApplication,QMessageBox
from dango.ui import Installer
from dango.i18n import languages
parser=argparse.ArgumentParser(description='Dango Loader live ISO installer')
parser.add_argument('--demo',action='store_true',help='Preview with synthetic disks; never run installer')
parser.add_argument('--branding',type=Path,help='Branding directory')
parser.add_argument('--language',choices=languages(),help='Override locale for preview/testing')
args=parser.parse_args()
from dango.startup import administrator_start
try:status=administrator_start(sys.argv[1:],args.demo)
except Exception as error:print(str(error),file=sys.stderr);raise SystemExit(1)
if status is not None:raise SystemExit(status)
app=QApplication(sys.argv);app.setStyle('Fusion')
try:window=Installer(Path(__file__).resolve().parent,args.branding,args.language,args.demo)
except Exception as error:QMessageBox.critical(None,'Dango Loader',str(error));raise SystemExit(1)
window.show();raise SystemExit(app.exec())
