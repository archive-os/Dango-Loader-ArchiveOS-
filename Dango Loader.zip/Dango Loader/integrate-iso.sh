#!/bin/sh
set -eu
DANGO_PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec /usr/bin/python3 "$DANGO_PROJECT_DIR/integrate-iso.py" "$@"
