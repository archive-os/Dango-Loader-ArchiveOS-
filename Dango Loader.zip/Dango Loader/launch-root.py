#!/usr/bin/python3 -I
"""Fixed installed entry point for administrator startup; no user code imports."""
import os,sys
from pathlib import Path
def trusted(path):
 path=Path(path).resolve(strict=True)
 for part in [path,*path.parents]:
  info=part.stat()
  if info.st_uid!=0 or info.st_mode&0o022:raise PermissionError('Administrator launcher must be protected: '+str(part))
 return path
if __name__=='__main__':
 if os.geteuid()!=0:raise SystemExit('Administrator authorization is required')
 root=trusted(__file__).parent;main=trusted(root/'main.py')
 for path in (root/'dango').glob('*.py'):trusted(path)
 # Polkit allow_gui preserves DISPLAY/XAUTHORITY; use XWayland for a root GUI.
 os.environ['QT_QPA_PLATFORM']='xcb'
 for key in ('QT_PLUGIN_PATH','QT_QPA_PLATFORM_PLUGIN_PATH','QML2_IMPORT_PATH','PYTHONPATH','PYTHONHOME'):os.environ.pop(key,None)
 os.execv('/usr/bin/python3',['/usr/bin/python3','-I',str(main),*sys.argv[1:]])
