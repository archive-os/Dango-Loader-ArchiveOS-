# Branding a distribution

This folder is independent from the installer backend. Copy it for your distribution and run `./run.sh --demo --branding /path/to/your/branding`.

- `branding.json`: name, website, relative logo path, accent/background hex colors, localized titles and fallback slides.
- `assets/logo.png`: replace with your own logo; transparency is supported.
- `slides/1.png` … `slides/10.png`: numbered slideshow images, only existing images are played. A 1280 × 520 canvas works well. PNG, JPEG and WebP are accepted.
- `slides/tr/`: optional Turkish versions. Add `slides/en/` for separate English versions if desired. An existing language folder takes precedence over the base folder.

Example accent change:

```json
"accent": "#78CF98"
```

Example translated title:

```json
"welcome_title": {"en": "Welcome to your system", "tr": "Sistemine hoş geldin"}
```

Logo and slides must resolve inside this branding folder. The interval is `slide_interval_ms` (default 5500). Ten ArchiveOS toolkit introduction slides are supplied in English and Turkish. Replace any of them with your own numbered images. Removing all numbered slides activates the translated text slides defined in `branding.json`. Branding changes do not enable real installation; backend settings are in `installer.json` / `/etc/dango-loader/installer.json`.
