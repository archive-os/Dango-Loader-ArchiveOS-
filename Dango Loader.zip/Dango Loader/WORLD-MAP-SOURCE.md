# Offline world map source

Outline data: Natural Earth, 1:110m countries. Retrieved 2026-10-07 from https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson . Dataset project: https://www.naturalearthdata.com/ .

Timezone points and identifiers come from the live system tzdata `zone.tab`; the map selects the nearest reference point. The outline is a visual aid, not authoritative timezone boundary data.
