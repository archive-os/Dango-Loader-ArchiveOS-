import sys,tempfile,json
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango import engine
with tempfile.TemporaryDirectory() as directory:
 media=Path(directory)/'cdrom';(media/'casper').mkdir(parents=True);source=media/'casper/filesystem.squashfs';source.write_bytes(b'hsqs-fixture')
 def trust(path):
  if Path(path)==source:raise PermissionError('ISO archived ownership')
  return Path(path)
 for fs,opts,valid in [('iso9660','ro,relatime',True),('squashfs','ro',True),('iso9660','rw',False),('ext4','ro',False),('fuse.iso','ro',False)]:
  report={'filesystems':[{'target':str(media),'fstype':fs,'options':opts}]}
  with patch('dango.engine.trusted',side_effect=trust),patch('dango.storage.capture',return_value=json.dumps(report)):
   try:assert engine.trusted_source(source)==source;accepted=True
   except PermissionError:accepted=False
   assert accepted==valid,(fs,opts)
 with patch('dango.engine.trusted',side_effect=PermissionError('Writable source/mount parent')),patch('dango.storage.capture',return_value=json.dumps({'filesystems':[{'target':str(media),'fstype':'iso9660','options':'ro'}]})):
  try:engine.trusted_source(source);raise AssertionError('Unprotected mount ancestor accepted')
  except PermissionError:pass
 for report in [{'filesystems':[]},{'filesystems':[{'target':'/elsewhere','fstype':'iso9660','options':'ro'}]},{}]:
  with patch('dango.engine.trusted',side_effect=trust),patch('dango.storage.capture',return_value=json.dumps(report)):
   try:engine.trusted_source(source);raise AssertionError('Bad mount report accepted')
   except PermissionError:pass
 with patch('dango.engine.trusted',return_value=source),patch('dango.storage.capture') as capture:
  assert engine.trusted_source(source)==source;capture.assert_not_called()
print('PASS: non-root archived read-only ISO9660/SquashFS source accepted; writable media, other filesystems, unprotected mount ancestors and ambiguous/outside reports refused; protected files retain strict trust.')
