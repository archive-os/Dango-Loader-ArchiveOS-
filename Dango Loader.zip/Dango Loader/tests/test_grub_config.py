import sys,tempfile
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango.engine import checked_grub_config,prepare_grub_config
broken='GRUB_DEFAULT=0\nGRUB_DISTRIBUTOR="ArchiveOS\nGRUB_CMDLINE_LINUX_DEFAULT="quiet splash"\n# manual `info grub`\n'
fixed=checked_grub_config(broken);assert 'GRUB_DISTRIBUTOR="ArchiveOS"\n' in fixed
assert checked_grub_config(fixed)==fixed
assert checked_grub_config("GRUB_DISTRIBUTOR='Other OS\n")=="GRUB_DISTRIBUTOR='Other OS'\n"
for malformed in ('GRUB_CMDLINE_LINUX="broken\n','if then\n','GRUB_DISTRIBUTOR="$(touch /tmp/dango-no-exec)\n'):
 try:checked_grub_config(malformed);raise AssertionError('Unexpected repair')
 except ValueError:pass
assert not Path('/tmp/dango-no-exec').exists()
with tempfile.TemporaryDirectory() as directory,patch('dango.engine.event'):
 root=Path(directory);(root/'etc/default/grub.d').mkdir(parents=True);p=root/'etc/default/grub';p.write_text(broken)
 prepare_grub_config(root);assert p.read_text()==fixed;assert (root/'etc/default/grub.dango-backup').read_text()==broken
 prepare_grub_config(root);assert p.read_text()==fixed
 (root/'etc/default/grub.d/99-test.cfg').write_text('GRUB_TIMEOUT="bad\n')
 try:prepare_grub_config(root);raise AssertionError('Broken override accepted')
 except ValueError:pass
source=Path('/home/hakki/aos-make/aos-squash-data/extracted/etc/default/grub')
if source.is_file():assert 'GRUB_DISTRIBUTOR="ArchiveOS"' in checked_grub_config(source.read_text())
print('PASS: real source missing quote reproduced/repaired, valid config unchanged, arbitrary syntax rejected, target original backed up, invalid override rejected, shell check does not execute content; no disk commands.')
