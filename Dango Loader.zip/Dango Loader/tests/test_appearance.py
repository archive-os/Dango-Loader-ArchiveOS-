import os,sys,time
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen';BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from PyQt6.QtWidgets import QApplication,QComboBox
from PyQt6.QtGui import QPalette,QColor
from PyQt6.QtCore import Qt
from PyQt6.QtTest import QTest
from zoneinfo import available_timezones
from dango.ui import Installer
from dango.keyboards import keyboard_catalog
from dango.model import validate_user
app=QApplication([]);app.setStyle('Fusion')
def settle():
 for _ in range(30):app.processEvents();time.sleep(.01)
for lang in ('tr','en'):
 w=Installer(BASE,lang=lang,demo=True);w.resize(900,680);w.show();settle()
 assert not w.zone.isEditable();assert {w.zone.itemText(i) for i in range(w.zone.count())}==available_timezones()|{'UTC'}
 assert w.keyboard.count()==len(keyboard_catalog()) and w.keyboard.count()>50
 w.keyboard.setCurrentIndex(w.keyboard.findData('tr'));assert w.keyboard_variants.findData('f')>=0
 w.keyboard_variants.setCurrentIndex(w.keyboard_variants.findData('f'));assert w.plan()['keyboard_variant']=='f'
 w.keyboard.setCurrentIndex(w.keyboard.findData('us'));assert w.keyboard_variants.findData('dvorak')>=0
 data=dict(w.plan(),username='dango',hostname='dango-pc',fullname='Dango',password='test-password');validate_user(data)
 try:validate_user(dict(data,keyboard_variant='not-a-real-variant'));raise AssertionError('Invalid variant allowed')
 except ValueError:pass
 for mode in ('light','dark','system'):
  w.theme_choice.setCurrentIndex(w.theme_choice.findData(mode));settle()
  if mode!='system':assert w.dark==(mode=='dark')
  assert w.zone.view().palette().color(QPalette.ColorRole.Text).lightness()>(128 if w.dark else -1)
  for step in (0,1,2,3,6):
   w.go(step);settle()
   if step==1:
    point=next(p for p in w.timezone_map.points if p[0]=='Europe/Istanbul');pixel=w.timezone_map.project(point[1],point[2]).toPoint();QTest.mouseClick(w.timezone_map,Qt.MouseButton.LeftButton,pos=pixel);assert w.zone.currentText()=='Europe/Istanbul'
    w.zone.setCurrentText('Asia/Tokyo');assert w.timezone_map.zone=='Asia/Tokyo'
   if step==6:
    assert len(w.slide_files())==10
    for i in range(10):w.slide_index=i;w.update_slide();assert not w.slide.pixmap().isNull()
    w.terminal_toggle.setChecked(True);w.handle_event({'progress':65,'message':'configure_system'});settle();assert w.percent.text()=='65%'
   w.grab().save(f'/tmp/dango-new-{lang}-{mode}-{step}.png')
 for i in (1,2,3,2,1,0):w.go(i)
 settle();assert w.running_animation is None
 w.close()
print('PASS: all tzdata zones, offline map click/list sync, full XKB layouts/variants and validation, light/dark/system palettes, responsive 900x680 renders, 10 slides in both themes/languages, percent/logs and rapid page transitions')
print('Layouts:',len(keyboard_catalog()),'Variants:',sum(len(x['variants']) for x in keyboard_catalog().values()),'Timezones:',len(available_timezones()))
