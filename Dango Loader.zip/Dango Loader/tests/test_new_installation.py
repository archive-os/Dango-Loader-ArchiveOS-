import os,sys,copy,tempfile,subprocess,fcntl
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen';os.environ['QT_LOGGING_RULES']='qt.text.font.db=false';BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango.storage import fixture,physical_disks,disk_identity,GIB,flatten,device_identity
from dango.model import validate_plan
from dango.i18n import languages,locale_for,translate
from dango.session_keyboard import apply_keyboard
from dango.ui import Installer
from PyQt6.QtWidgets import QApplication
app=QApplication([]);w=Installer(BASE,lang='tr',demo=True);w.show();app.processEvents()
assert len(languages())>=80 and w.language_choice.count()==len(languages())
w.select_storage('erase');assert w.fs.currentText()=='Btrfs' and w.zram.isChecked() and w.storage_stack.currentIndex()==1
w.disk_confirm.setChecked(True);w.fullname.setText('Tester');w.username.setText('tester');w.password.setText('test-secret');w.confirm_password.setText('test-secret')
data=w.plan();disk,efi=validate_plan(data,w.inventory,w.profile);assert efi is None and disk['path']=='/dev/demo'
# An entirely empty physical disk is discoverable and usable in erase mode.
blank={'uefi':True,'devices':[copy.deepcopy(disk)],'systems':[],'boot_entries':[]};w.inventory=blank;w.fill_devices();assert w.disk_combo.count()==1
w.disk_confirm.setChecked(True);data=w.plan();validate_plan(data,blank,w.profile)
for mutation in ('identity','mounted','confirmation','read_only','too_small'):
 inv=copy.deepcopy(blank);request=copy.deepcopy(data)
 if mutation=='identity':inv['devices'][0]['size']+=GIB
 if mutation=='mounted':inv['devices'][0]['mountpoints']=['/cdrom']
 if mutation=='confirmation':request['erase_confirmed']=False
 if mutation=='read_only':inv['devices'][0]['ro']=True
 if mutation=='too_small':inv['devices'][0]['size']=GIB
 try:validate_plan(request,inv,w.profile);raise AssertionError('Erase guard bypassed: '+mutation)
 except ValueError:pass
w.go(3,False);w.advance();assert w.step==3 and w.storage_stack.currentIndex()==2 and w.swap.currentData()=='auto'
w.zram.setChecked(False);assert w.plan()['swap']=='off';w.zram.setChecked(True);w.advance();assert w.step==4
w.go(0,False);w.language_choice.setCurrentIndex(w.language_choice.findData('fr'));app.processEvents();assert w.lang=='fr' and 'Clavier' in w.steps[2].text() and w.password.text()=='test-secret'
assert locale_for('de').startswith('de_') and locale_for('tr').startswith('tr_')
assert all(translate(code,'Keyboard') for code in languages())
w.close()
with patch.dict(os.environ,{'WAYLAND_DISPLAY':'fixture'}),patch('dango.session_keyboard.shutil.which',return_value='/usr/bin/kwriteconfig6'),patch('dango.session_keyboard.subprocess.run',return_value=subprocess.CompletedProcess([],0,stdout='',stderr='')) as run:
 assert apply_keyboard('tr','f')=='plasma';args=[x.args[0] for x in run.call_args_list]
 assert args[-1][-2:]==['--notify','f'] and any(a[-2:]==['LayoutList','tr'] for a in args)
 with patch('dango.session_keyboard.subprocess.run',return_value=subprocess.CompletedProcess([],1,stdout='',stderr='fixture error')):
  try:apply_keyboard('us');raise AssertionError('Keyboard failure swallowed')
  except RuntimeError:pass
assert apply_keyboard('us',demo=True)=='preview'
# Legacy startup helper disables only the known old launchers and keeps backups.
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory);(root/'etc/skel/.config/autostart').mkdir(parents=True);(root/'etc/xdg/autostart').mkdir(parents=True);(root/'usr').mkdir();(root/'etc/os-release').write_text('ID=archiveos\n')
 old=root/'etc/skel/.config/autostart/welcome-live.desktop';old.write_text('[Desktop Entry]\nExec=sudo /usr/bin/welcome1.py\n')
 unrelated=root/'etc/xdg/autostart/keep.desktop';unrelated.write_text('[Desktop Entry]\nExec=keep\n')
 subprocess.run([sys.executable,str(BASE/'fix-live-startup.py'),str(root)],check=True,stdout=subprocess.DEVNULL);assert 'Hidden=true' in old.read_text() and 'Hidden' not in unrelated.read_text();assert list((root/'var/backups/dango-live-startup').iterdir())
print('PASS: 82 language choices, French live retranslation/account preservation, blank disk recognition, erase identity/mount/size/confirmation/RO guards, separate recommended-on zram, Plasma keyboard variant+notify/failure mock, scoped legacy autostart backup/disable')
