import sys,os,types
from pathlib import Path
from unittest.mock import patch,Mock
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango.startup import administrator_start
with patch('dango.startup.os.geteuid',return_value=1000),patch('dango.startup.subprocess.run') as run:
 assert administrator_start(['--demo'],True) is None;run.assert_not_called()
with patch('dango.startup.os.geteuid',return_value=0),patch('dango.startup.subprocess.run') as run:
 assert administrator_start([]) is None;run.assert_not_called()
for status in (0,126,127):
 with patch('dango.startup.os.geteuid',return_value=1000),patch('dango.startup.Path.is_file',return_value=True),patch('dango.startup.subprocess.run',return_value=types.SimpleNamespace(returncode=status)) as run:
  assert administrator_start(['--language','tr'])==status
  assert run.call_args.args[0]==['pkexec','/usr/share/dango-loader/launch-root.py','--language','tr']
from dango import session_keyboard
with patch.dict(os.environ,{'PKEXEC_UID':'1000','XDG_CURRENT_DESKTOP':'KDE'},clear=True),patch('dango.session_keyboard.os.geteuid',return_value=0),patch('dango.session_keyboard.pwd.getpwuid',return_value=types.SimpleNamespace(pw_name='tester',pw_dir='/home/tester')),patch('dango.session_keyboard.shutil.which',return_value='/usr/bin/kwriteconfig6'),patch('dango.session_keyboard.subprocess.run',return_value=types.SimpleNamespace(returncode=0,stderr='')) as run:
 session_keyboard.apply_keyboard('tr','f')
 assert run.call_count==5
 for call in run.call_args_list:
  assert call.args[0][:4]==['/usr/sbin/runuser','-u','tester','--']
  assert call.kwargs['env']['XDG_CONFIG_HOME']=='/home/tester/.config'
  assert call.kwargs['env']['DBUS_SESSION_BUS_ADDRESS']=='unix:path=/run/user/1000/bus'
 assert '--notify' in run.call_args.args[0]
# A root GUI calls the installed helper directly, rather than invoking pkexec again.
from dango import ui
fake=types.SimpleNamespace(busy=False,error_label=Mock(),t=lambda tr,en:en,read_helper=Mock(),helper_finished=Mock(),finish=Mock())
with patch('dango.ui.os.geteuid',return_value=0),patch('dango.ui.Path.is_file',return_value=True),patch('dango.ui.QProcess') as process:
 ui.Installer.start_helper(fake,{'action':'scan'},True)
 process.return_value.start.assert_called_once_with('/usr/bin/python3',['-I','/usr/share/dango-loader/helper.py'])
print('PASS: startup authorization, already-root/demo bypass, cancellation/exit codes, originating-user keyboard settings and direct root helper without a second prompt; authorization/processes mocked.')
