import copy,json,sys,tempfile,os
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango import model,storage,engine
profile=json.loads((BASE/'installer.json').read_text())
user=dict(fullname='Tester',username='tester',hostname='archiveos',password='abcdefgh',timezone='UTC',keyboard='us',keyboard_variant='',language='en')
for strong,length,ok in [(True,0,False),(True,7,False),(True,8,True),(False,0,False),(False,1,True),(False,2,True),(False,3,True),(False,300,True)]:
 data=dict(user,secure_password=strong,password='x'*length)
 try:model.validate_user(data);accepted=True
 except ValueError:accepted=False
 assert accepted==ok,(strong,length)
for ram,ok in [(2048,False),(3839,False),(3840,True),(4096,True)]:
 try:model.validate_hardware({'memory_mib':ram},profile);accepted=True
 except ValueError:accepted=False
 assert accepted==ok,ram
inv=storage.fixture();inv['uefi']=False;disk=inv['devices'][0]
plan=dict(user,mode='manual',root_device='/dev/demo4',root_uuid='DEMO-LINUX',filesystem='btrfs',swap='off',format_confirmed=True)
try:model.validate_plan(plan,inv,profile);raise AssertionError('Missing bios_grub accepted')
except ValueError as e:assert 'bios_grub' in str(e)
inv['devices'].append(dict(path='/dev/demo2',type='part',size=2*storage.MIB,disk='/dev/demo',ro=False,mountpoints=[],parttype=storage.BIOS_GRUB_GUID,partuuid='BIOS-PART'))
root,efi=model.validate_plan(plan,inv,profile);assert efi is None
minimum=model.minimum_root_bytes(inv,profile)
for size,ok in [(minimum-1,False),(minimum,True)]:
 current=copy.deepcopy(inv);next(r for r in current['devices'] if r['path']=='/dev/demo4')['size']=size
 try:model.validate_plan(plan,current,profile);accepted=True
 except ValueError:accepted=False
 assert accepted==ok,size
mbr=copy.deepcopy(inv);mbr['devices'][0]['pttype']='dos';mbr['devices']=[r for r in mbr['devices'] if r.get('parttype')!=storage.BIOS_GRUB_GUID];assert model.validate_plan(plan,mbr,profile)[1] is None
# Both firmware paths and filesystems, mocked destructive commands only.
for uefi in (False,True):
 for fs in ('btrfs','ext4'):
  with tempfile.TemporaryDirectory() as directory:
   target=Path(directory)/'target';target.mkdir();calls=[]
   data=dict(user,mode='erase',filesystem=fs,swap='off')
   parts={'uefi':uefi,'devices':[disk,dict(path='/dev/demo1',disk='/dev/demo',type='part',parttype=storage.BIOS_GRUB_GUID),dict(path='/dev/demo2',disk='/dev/demo',type='part')]}
   def run(args,secret=None,answer=None):
    calls.append(args)
    if args[0]=='unsquashfs':(target/'etc').mkdir(exist_ok=True);(target/'etc/passwd').write_text('root:x:0:0:root:/root:/bin/bash\n')
    if args[0]=='blkid':return 'EFI-UUID' if args[-1]=='/dev/demo1' else 'ROOT-UUID'
    if args[0]=='openssl':return '$6$fixture'
    return ''
   with patch('dango.engine.preflight',return_value=(disk,None)),patch('dango.engine.validate_plan'),patch('dango.engine.tempfile.mkdtemp',return_value=str(target)),patch('dango.engine.run',side_effect=run),patch('dango.engine.event'),patch('dango.storage.discover',return_value=parts):engine.execute(data,profile)
   grub=next(a for a in calls if 'grub-install' in a)
   fstab=(target/'etc/fstab').read_text()
   if uefi:assert '--target=x86_64-efi' in grub and '/boot/efi' in fstab
   else:
    assert '--target=i386-pc' in grub and grub[-1]=='/dev/demo'
    assert ['parted','--script','/dev/demo','set','1','bios_grub','on'] in calls
    assert '/boot/efi' not in fstab and not any(a[0]=='mkfs.vfat' for a in calls)
# Password UI: checkbox, plan payload and translated explanations; no host keyboard change.
os.environ['QT_QPA_PLATFORM']='offscreen'
from PyQt6.QtWidgets import QApplication
from dango.ui import Installer
app=QApplication([])
for lang in ('tr','en'):
 win=Installer(BASE,demo=True,lang=lang);win.show();app.processEvents();win.go(4,False)
 assert win.secure_password.isChecked() and win.plan()['secure_password']
 win.secure_password.setChecked(False);assert not win.plan()['secure_password']
 assert 'sudo' in win.password_note.text().lower() and '8' in win.password_note.text() and '1' in win.password_note.text()
 win.grab().save('/tmp/dango-030-password-'+lang+'.png');win.close()
print('PASS: short/strong/empty password policies, 4-GiB RAM threshold, 32-GB total storage boundary, BIOS GPT/MBR safeguards, UEFI/BIOS erase GRUB/fstab/Btrfs-Ext4 mocks and EN/TR password UI.')

for uefi in (False,True):
 for capacity,ok in [(31_999_999_999,False),(32_000_000_000,True),(32*storage.GIB,True),(40*storage.GIB,True)]:
  current=storage.fixture();current['uefi']=uefi;current['devices']=[dict(current['devices'][0],size=capacity)]
  disk=current['devices'][0];data=dict(user,mode='erase',filesystem='btrfs',swap='auto',disk_device=disk['path'],disk_identity=storage.disk_identity(disk),erase_confirmed=True)
  try:model.validate_plan(data,current,profile);accepted=True
  except ValueError as e:
   accepted=False;assert 'GB detected' in str(e)
  assert accepted==ok,(uefi,capacity)
print('PASS: 32-GB exact decimal disks and 32-GiB disks accepted in BIOS/UEFI; below-minimum disks rejected with detected/required sizes.')
