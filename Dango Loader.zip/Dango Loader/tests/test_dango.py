import os,json,tempfile,sys,time,shutil
from pathlib import Path
from unittest.mock import patch
os.environ['QT_QPA_PLATFORM']='offscreen';BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango.branding import load_branding,language
from dango.model import validate_plan,public_plan
from dango.storage import fixture,alongside_layout,GIB,MIB
from dango.engine import swap_mib,target_path,setup_swap
from dango.ui import Installer
from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QPixmap
app=QApplication([]);app.setStyle('Fusion');brand=load_branding(BASE/'branding')
with patch.dict(os.environ,{'LC_ALL':'tr_TR.UTF-8'}):assert language()=='tr'
with patch.dict(os.environ,{'LC_ALL':'de_DE.UTF-8'}):assert language().startswith('de')
assert swap_mib(2048)==2048 and swap_mib(8192)==4096 and swap_mib(65536)==8192
layout=alongside_layout(MIB,380*GIB,60,110*GIB)
assert layout['root_bytes']==60*GIB and layout['windows_bytes']>=110*GIB
try:alongside_layout(MIB,100*GIB,90,80*GIB);raise AssertionError('Unsafe shrink accepted')
except ValueError:pass
with tempfile.TemporaryDirectory() as directory:
    root=Path(directory);(root/'escape').symlink_to('/etc')
    try:target_path(root,'escape/passwd');raise AssertionError('Target escape accepted')
    except ValueError:pass
    setup_swap(root);assert (root/'etc/systemd/system/multi-user.target.wants/dango-zram.service').is_symlink()
for lang in ('en','tr'):
    w=Installer(BASE,lang=lang,demo=True);w.show();app.processEvents();assert w.fs.currentText()=='Btrfs'
    w.root_combo.setCurrentIndex(w.root_combo.findData('/dev/demo4'));w.efi_combo.setCurrentIndex(w.efi_combo.findData('/dev/demo1'));w.disk_confirm.setChecked(True)
    w.fullname.setText('Dango User');w.username.setText('dango');w.password.setText('test-secret-42');w.confirm_password.setText('test-secret-42')
    plan=w.plan();validate_plan(plan,w.inventory,w.profile);assert 'password' not in public_plan(plan)
    with patch('dango.ui.shutil.which',return_value='/usr/bin/partitionmanager'),patch('dango.ui.QProcess.startDetached',return_value=(True,123)) as launch:
        w.open_partition_manager();assert launch.call_args.args==('/usr/bin/partitionmanager',[])
    w.alongside.setChecked(True);w.root_combo.setCurrentIndex(w.root_combo.findData('/dev/demo3'));w.check_limits();assert w.ntfs_device=='/dev/demo3' and w.size.maximum()>25
    w.bar.setValue(75);assert w.size.value()==75
    w.disk_confirm.setChecked(True);validate_plan(w.plan(),w.inventory,w.profile)
    changed=json.loads(json.dumps(w.inventory));changed['devices'][1]['uuid']='changed'
    try:validate_plan(w.plan(),changed,w.profile);raise AssertionError('Changed device accepted')
    except ValueError:pass
    mounted=json.loads(json.dumps(w.inventory));mounted['devices'][3]['mountpoints']=['/']
    try:validate_plan(w.plan(),mounted,w.profile);raise AssertionError('Busy disk accepted')
    except ValueError:pass
    for step in range(6):
        w.go(step)
        for _ in range(25):app.processEvents();time.sleep(.01)
        assert w.running_animation is None
        assert w.grab().save(f'/tmp/dango-{lang}-{step}.png')
    w.start_install();assert w.busy and w.step==6
    w.terminal_toggle.setChecked(True);assert w.terminal.isVisible()
    for _ in range(25):app.processEvents();time.sleep(.01)
    w.grab().save(f'/tmp/dango-{lang}-install.png')
    w.demo_timer.stop()
    for _ in range(11):
        if w.demo_index<11:w.demo_tick()
    assert w.step==7 and not w.busy and not w.password.text()
    assert 'test-secret-42' not in w.terminal.toPlainText()
    w.close()
with tempfile.TemporaryDirectory() as directory:
    folder=Path(directory)/'branding';shutil.copytree(BASE/'branding',folder)
    data=json.loads((folder/'branding.json').read_text());data['accent']='#78CF98';(folder/'branding.json').write_text(json.dumps(data))
    # Only existing 1..10 PNGs count, even when there are gaps and unrelated files.
    slides=folder/'slides';shutil.rmtree(slides);slides.mkdir()
    for i in (1,3,5,11):
        p=QPixmap(120,80);p.fill();p.save(str(slides/f'{i}.png'))
    w=Installer(BASE,branding=folder,lang='en',demo=True);assert w.brand['accent']=='#78CF98'
    assert [p.stem for p in w.slide_files()]==['1','3','5'];w.next_slide();assert not w.slide.pixmap().isNull();w.close()
print('PASS: locale fallback, branding color, Btrfs default, resize geometry/limits, mounted/identity guards, KDE partition manager, RAM swap, target escape, 12 page renders, demo/terminal/no-secret and numbered slides')
