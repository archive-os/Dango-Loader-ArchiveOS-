import os,sys,copy
from pathlib import Path
from unittest.mock import Mock
os.environ['QT_QPA_PLATFORM']='offscreen';BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from PyQt6.QtWidgets import QApplication,QLineEdit
from PyQt6.QtCore import Qt
from PyQt6.QtTest import QTest
from dango.ui import Installer
from dango.storage import fixture,disk_identity
from dango.model import validate_storage
app=QApplication([])
for lang in ('tr','en'):
 w=Installer(BASE,lang=lang,demo=True);w.show();w.go(3,False)
 inv=fixture();other=[]
 for row in copy.deepcopy(inv['devices']):
  row['path']=row['path'].replace('/dev/demo','/dev/other');row['disk']='/dev/other'
  if row.get('uuid'):row['uuid']='OTHER-'+row['uuid']
  other.append(row)
 inv['devices']+=other
 w.demo=False;w.start_helper=Mock();QTest.mouseClick(w.scan_button,Qt.MouseButton.LeftButton);w.start_helper.assert_called_once_with({'action':'scan'},True)
 w.handle_event({'inventory':inv});app.processEvents();assert w.disk_combo.isVisible() and w.disk_combo.count()==2
 w.disk_combo.setCurrentIndex(w.disk_combo.findData('/dev/other'));w.select_storage('erase');w.disk_confirm.setChecked(True)
 assert w.plan()['disk_device']=='/dev/other';root,efi=validate_storage(w.plan(),inv,w.profile);assert root['path']=='/dev/other'
 w.select_storage('alongside');assert w.root_combo.count()==1 and w.root_combo.currentData()=='/dev/other3';assert w.efi_combo.currentData()=='/dev/other1'
 w.disk_confirm.setChecked(True);root,efi=validate_storage(w.plan(),inv,w.profile);assert root['disk']==efi['disk']=='/dev/other'
 bad=dict(w.plan(),disk_device='/dev/demo',disk_identity=disk_identity(inv['devices'][0]))
 try:validate_storage(bad,inv,w.profile);raise AssertionError('Cross-disk plan accepted')
 except ValueError as e:assert 'selected installation disk' in str(e)
 w.ntfs_device='/dev/other3';w.disk_combo.setCurrentIndex(w.disk_combo.findData('/dev/demo'));assert w.root_combo.currentData()=='/dev/demo3' and not w.disk_confirm.isChecked() and w.ntfs_device is None
 w.handle_event({'inventory':inv});assert w.disk_combo.currentData()=='/dev/demo'
 w.storage_stack.setCurrentIndex(2);app.processEvents();assert not w.disk_combo.isVisible();w.previous();app.processEvents();assert w.disk_combo.isVisible()
 w.select_storage('erase')
 for _ in range(5):app.processEvents()
 w.grab().save(f'/tmp/dango035-disks-{lang}.png')
 w.go(2,False);assert not w.pages.currentWidget().findChildren(QLineEdit)
 w.go(6,False);app.processEvents();assert not w.sidebar.isVisible();assert w.slide.pixmap().width()>w.width()*.85,(w.slide.pixmap().width(),w.width())
 w.grab().save(f'/tmp/dango035-slides-{lang}.png');w.demo=True;w.close()
print('PASS two-disk authorized scan selection, erase/Windows disk binding, filtered root+EFI, backend cross-disk rejection, confirmation/limits invalidation, no keyboard input, full-width slideshow TR/EN; no real disk modifications.')
