import sys,tempfile,copy,json
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango import engine,storage
profile=json.loads((BASE/'installer.json').read_text());disk=storage.fixture()['devices'][0]
for fs in ('btrfs','ext4'):
 with tempfile.TemporaryDirectory() as directory:
  target=Path(directory)/'target';target.mkdir();calls=[];events=[]
  data={'mode':'erase','filesystem':fs,'swap':'auto','timezone':'Europe/Berlin','keyboard':'de','keyboard_variant':'','language':'de','fullname':'Tester','username':'tester','hostname':'archiveos-pc','password':'test-secret'}
  inv={'uefi':True,'devices':[disk,dict(path='/dev/demo1',disk='/dev/demo',type='part',uuid=None),dict(path='/dev/demo2',disk='/dev/demo',type='part',uuid=None)]}
  def run(args,secret=None,answer=None):
   calls.append(args)
   if args[0]=='unsquashfs':
    (target/'etc').mkdir(exist_ok=True);(target/'etc/passwd').write_text('root:x:0:0:root:/root:/bin/bash\n')
   if args[0]=='blkid':return 'EFI-UUID' if args[-1]=='/dev/demo1' else 'ROOT-UUID'
   if args[0]=='openssl':return '$6$fixture'
   return ''
  with patch('dango.engine.preflight',return_value=(disk,None)),patch('dango.engine.validate_plan'),patch('dango.engine.tempfile.mkdtemp',return_value=str(target)),patch('dango.engine.run',side_effect=run),patch('dango.engine.event',side_effect=lambda p,m:events.append((p,m))),patch('dango.storage.discover',return_value=inv):engine.execute(data,profile)
  assert events[-1]==(100,'complete') and 'erase_disk' in [m for p,m in events]
  assert calls[0]==['parted','--script','/dev/demo','mklabel','gpt']
  assert ['parted','--script','/dev/demo','set','1','esp','on'] in calls
  assert ['mkfs.vfat','-F','32','/dev/demo1'] in calls and any(a[0]=='mkfs.'+fs and a[-1]=='/dev/demo2' for a in calls)
  assert all('/dev/otherdisk' not in a for a in calls)
  fstab=(target/'etc/fstab').read_text();assert 'EFI-UUID' in fstab and 'ROOT-UUID' in fstab
  assert 'LANG=de_' in (target/'etc/default/locale').read_text()
  assert 'test-secret' not in repr(calls)
print('PASS: erase branch GPT/EFI/root creation, scoped device formatting, Btrfs/Ext4, locale selection, fstab, user/swap/bootloader/unmount and success; all disk subprocesses mocked')
