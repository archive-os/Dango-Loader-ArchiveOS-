import os,sys
from pathlib import Path
from unittest.mock import Mock
os.environ['QT_QPA_PLATFORM']='offscreen'
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from PyQt6.QtWidgets import QApplication,QPushButton
from PyQt6.QtCore import Qt
from PyQt6.QtTest import QTest
from dango.ui import Installer
from dango.storage import fixture
app=QApplication([])
for lang in ('tr','en'):
 w=Installer(BASE,lang=lang,demo=True);w.show();w.go(3,False);app.processEvents()
 buttons=[b.text() for b in w.disk_controls.findChildren(QPushButton)]
 assert buttons==(['Disk algılama','Gelişmiş'] if lang=='tr' else ['Detect disks','Advanced']),buttons
 w.inventory={'devices':[],'systems':[],'boot_entries':[],'uefi':False};w.fill_devices();assert w.disk_combo.count()==0
 QTest.mouseClick(w.scan_button,Qt.MouseButton.LeftButton);assert w.disk_combo.count()>0
 for i in range(w.disk_combo.count()):assert w.disk_combo.itemData(i) in w.disk_combo.itemText(i)
 w.demo=False;w.start_helper=Mock();QTest.mouseClick(w.scan_button,Qt.MouseButton.LeftButton);w.start_helper.assert_called_once_with({'action':'scan'},True)
 w.handle_event({'inventory':fixture()});assert w.disk_combo.count()>0 and not w.error_label.text()
 w.demo=True;w.select_storage('erase');w.disk_confirm.setChecked(True);selected=w.disk_combo.currentData();w.advance();app.processEvents()
 assert w.storage_stack.currentIndex()==2 and not w.disk_controls.isVisible()
 assert not w.disk_combo.isVisible() and not w.fs.isVisible() and w.zram.isVisible()
 assert w.storage_title.text()==('Bellek ayarları' if lang=='tr' else 'Memory settings')
 assert w.plan()['disk_device']==selected and w.plan()['erase_confirmed']
 w.grab().save(f'/tmp/dango032-zram-{lang}.png')
 w.previous();app.processEvents();assert w.disk_controls.isVisible() and w.disk_combo.isVisible()
 assert w.plan()['disk_device']==selected
 w.grab().save(f'/tmp/dango032-disks-{lang}.png');w.close()
print('PASS: one authorized scan button, detected disks visible, helper inventory refresh, isolated zram view, back navigation preserves disk selection; TR/EN offscreen.')
