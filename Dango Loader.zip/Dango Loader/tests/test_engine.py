"""Command-order/failure checks: every installer subprocess is mocked."""
import copy,json,sys,tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dango import engine,storage
BASE=Path(__file__).resolve().parents[1];profile=json.loads((BASE/'installer.json').read_text())
try:
    with patch('dango.engine.os.geteuid',return_value=0):engine.preflight({},dict(profile,allow_real_install=False))
    raise AssertionError('Development installation gate bypassed')
except PermissionError:pass
inventory=storage.fixture();root=next(r for r in inventory['devices'] if r['path']=='/dev/demo4');efi=next(r for r in inventory['devices'] if r['path']=='/dev/demo1');windows=next(r for r in inventory['devices'] if r['path']=='/dev/demo3')
for mode,fs,failure in [('manual','btrfs',None),('manual','ext4','unsquashfs'),('alongside','xfs',None)]:
    with tempfile.TemporaryDirectory() as directory:
        target=Path(directory)/'target';target.mkdir();commands=[];events=[];created=False
        data={'mode':mode,'filesystem':fs,'swap':'auto','root_gib':60,'timezone':'Europe/Istanbul','keyboard':'tr-f','language':'tr','fullname':'Dango User','hostname':'archiveos-pc','username':'dango','password':'secret-test-42'}
        def run(args,secret=None,answer=None):
            global created
            commands.append((args,secret,answer))
            if args[0]==failure:raise RuntimeError('Fixture failure')
            if args[0]=='ntfsls':return 'kernel32.dll'
            if args[0]=='blockdev':return '512'
            if args[0]=='parted' and 'mkpart' in args:created=True
            if args[0]=='unsquashfs':
                (target/'etc').mkdir(exist_ok=True);(target/'etc/passwd').write_text('root:x:0:0:root:/root:/bin/bash\n')
            if args[0]=='blkid':return 'new-root-uuid'
            if args[0]=='openssl':return '$6$fixturehash'
            return ''
        def discover():
            inv=copy.deepcopy(inventory)
            if created:inv['devices'].append(dict(root,path='/dev/demo5',uuid='new-root-uuid'))
            return inv
        layout=storage.alongside_layout(storage.MIB,380*storage.GIB,60,110*storage.GIB)
        geometry=[(3,storage.MIB,380*storage.GIB),(3,storage.MIB,layout['windows_end'])]
        with patch('dango.engine.preflight',return_value=(windows if mode=='alongside' else root,efi)),patch('dango.engine.validate_plan'),patch('dango.engine.run',side_effect=run),patch('dango.engine.event',side_effect=lambda p,m:events.append((p,m))),patch('dango.engine.tempfile.mkdtemp',return_value=str(target)),patch('dango.storage.discover',side_effect=discover),patch('dango.storage.ntfs_limits',return_value=110*storage.GIB),patch('dango.storage.geometry',side_effect=geometry):
            if failure:
                try:engine.execute(data,profile);raise AssertionError('Failure swallowed')
                except RuntimeError as e:assert str(e)=='Fixture failure'
                assert not any(p==100 for p,m in events)
                assert commands[-1][0][:2]==['umount','--recursive']
            else:
                engine.execute(data,profile);assert events[-1]==(100,'complete')
                mkfs=next(args for args,_,_ in commands if args[0]=='mkfs.'+fs)
                assert mkfs[-3:-1]==['-L','DangoRoot / ArchiveOS' if fs=='btrfs' else 'ArchiveOS']
                assert 'secret-test-42' not in repr([args for args,secret,answer in commands])
                assert data['password']==''
                fstab=(target/'etc/fstab').read_text();assert 'new-root-uuid' in fstab and efi['uuid'] in fstab
                assert (target/'etc/systemd/system/multi-user.target.wants/dango-zram.service').is_symlink()
                if fs=='btrfs':
                    home=next(i for i,c in enumerate(commands) if c[0][:3]==['mount','-o','subvol=@home,compress=zstd:3']);extract=next(i for i,c in enumerate(commands) if c[0][0]=='unsquashfs');assert home<extract and 'subvol=@home' in fstab
                if mode=='alongside':
                    partcmd=next(args for args,_,_ in commands if args[0]=='parted' and 'mkpart' in args)
                    assert json.loads(partcmd[partcmd.index('mkpart')+1])=='DangoRoot / ArchiveOS'
                    shrink=next(i for i,c in enumerate(commands) if c[0][0]=='ntfsresize' and '--no-action' not in c[0]);partition=next(i for i,c in enumerate(commands) if c[0][0]=='sfdisk' and '--no-act' not in c[0]);assert shrink<partition and commands[shrink][2]=='y\n'
                    assert '--force' not in repr(commands) and '-N' in commands[partition][0]
from xml.etree import ElementTree
policy=ElementTree.parse(BASE/'packaging/org.archiveos.dango-loader.policy');assert policy.find('.//annotate').text=='/usr/share/dango-loader/helper.py'
print('PASS: explicit disabled-profile gate, Btrfs home-before-extraction, filesystem/user/swap config, NTFS-before-partition order, stdin-only password, failure propagation and unmount cleanup; all disk commands mocked')
