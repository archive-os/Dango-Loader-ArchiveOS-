import os,sys
from pathlib import Path
os.environ['QT_QPA_PLATFORM']='offscreen'
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from PyQt6.QtWidgets import QApplication,QPushButton
from PyQt6.QtCore import Qt
from PyQt6.QtTest import QTest
from dango.ui import Installer
from dango.engine import root_partition_name,root_filesystem_label
profile={'bootloader_id':'ArchiveOS','root_partition_name':'DangoRoot / ArchiveOS'}
assert root_partition_name(profile)=='DangoRoot / ArchiveOS'
assert root_filesystem_label(profile,'btrfs')=='DangoRoot / ArchiveOS'
for fs,limit in [('ext4',16),('xfs',12)]:assert root_filesystem_label(profile,fs)=='ArchiveOS' and len(root_filesystem_label(profile,fs).encode())<=limit
assert root_partition_name({'bootloader_id':'OtherOS'})=='DangoRoot / OtherOS'
app=QApplication([])
for lang in ('tr','en'):
 w=Installer(BASE,lang=lang,demo=True);w.show();w.go(6,False)
 for _ in range(3):app.processEvents()
 assert w.slide.height()>=300,w.slide.height()
 assert isinstance(w.terminal_toggle,QPushButton) and w.terminal_window.isWindow() and not w.terminal_window.isModal()
 initial_height=w.slide.height();w.handle_event({'log':'first log'})
 QTest.mouseClick(w.terminal_toggle,Qt.MouseButton.LeftButton);app.processEvents()
 assert w.terminal_window.isVisible() and w.terminal.isVisible() and w.slide.height()==initial_height
 assert w.terminal.isReadOnly() and 'first log' in w.terminal.toPlainText()
 w.terminal_window.close();app.processEvents();assert not w.terminal_toggle.isChecked()
 w.handle_event({'log':'second log'});QTest.mouseClick(w.terminal_toggle,Qt.MouseButton.LeftButton);app.processEvents()
 assert all(x in w.terminal.toPlainText() for x in ('first log','second log'))
 w.terminal_window.grab().save(f'/tmp/dango034-terminal-{lang}.png');w.terminal_window.close()
 w.finish(False);app.processEvents();assert w.terminal_window.isVisible()
 w.terminal_window.close();w.grab().save(f'/tmp/dango034-install-{lang}.png');w.close();app.processEvents();assert not w.terminal_window.isVisible()
print('PASS: full GPT/Btrfs label and Ext4/XFS byte limits, enlarged slides, separate nonmodal log window, close/reopen log preservation, failure opens log window; TR/EN offscreen.')
