import sys,tempfile
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1];sys.path.insert(0,str(BASE))
from dango.live import is_live,desktop_shortcut
from dango.engine import remove_installer
assert is_live('quiet boot=casper',False) and is_live('boot=live quiet',False) and is_live('root=live:CDLABEL=AOS',False)
assert not is_live('quiet root=/dev/sda2',False) and not is_live('boot=casper-other',False) and is_live('',True)
with tempfile.TemporaryDirectory() as directory:
 root=Path(directory);source=root/'launcher';source.write_text('[Desktop Entry]\nName=Dango Loader\n')
 home=root/'home/live';desktop=home/'Masaüstü';assert desktop_shortcut(home,desktop,source,False) is None and not desktop.exists()
 shortcut=desktop_shortcut(home,desktop,source,True);assert shortcut.exists() and shortcut.stat().st_mode&0o111
 try:desktop_shortcut(home,root/'outside',source,True);raise AssertionError('Outside desktop accepted')
 except ValueError:pass
 target=root/'installed';(target/'var/lib/dpkg').mkdir(parents=True);(target/'var/lib/dpkg/status').write_text('Package: dango-loader\nStatus: install ok installed\n\nPackage: unrelated\nStatus: install ok installed\n')
 for relative in ('usr/bin/dango-loader','usr/share/dango-loader/main.py','home/new/Desktop/dango-loader.desktop','etc/skel/Desktop/dango-loader.desktop','etc/xdg/autostart/dango-loader-live.desktop'):
  p=target/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('fixture')
 unrelated=target/'usr/bin/keep-me';unrelated.write_text('keep')
 with patch('dango.engine.run') as run:remove_installer(target,['chroot',str(target)]);assert run.call_args.args[0]==['chroot',str(target),'dpkg','--purge','dango-loader']
 assert not (target/'usr/share/dango-loader').exists() and not (target/'home/new/Desktop/dango-loader.desktop').exists()
 assert unrelated.exists() and shortcut.exists() # live app and other packages are untouched
 # A purge failure must not pretend to have completed cleanup.
 with patch('dango.engine.run',side_effect=RuntimeError('fixture purge error')):
  try:remove_installer(target,['chroot',str(target)]);raise AssertionError('Purge error swallowed')
  except RuntimeError:pass
print('PASS: live detection, installed-session no-op, localized desktop shortcut/permissions/containment, target-only purge+shortcut cleanup, unrelated/live preservation and purge failure propagation')

import os,fcntl,subprocess
from dango.live import launch_live,main
with tempfile.TemporaryDirectory() as directory:
    with patch.dict(os.environ,{'DISPLAY':':fixture'}),patch('dango.live.subprocess.run',return_value=subprocess.CompletedProcess([],0)) as command:
        assert launch_live(directory)
        assert command.call_args.args[0]==['/usr/bin/dango-loader']
        lock=os.open(Path(directory)/'dango-loader-live.lock',os.O_RDWR);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:assert not launch_live(directory)
        finally:os.close(lock)
    with patch('dango.live.is_live',return_value=False),patch('dango.live.launch_live') as command:main();command.assert_not_called()
print('PASS: live automatic app launch, duplicate session lock, installed-session no launch; GUI subprocess mocked')
