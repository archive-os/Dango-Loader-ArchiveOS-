#!/usr/bin/python3
"""Disable only the two legacy live welcome entries in an extracted ISO tree."""
import argparse,re,shutil,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);args=parser.parse_args();root=args.root.resolve()
if root==Path('/') or not (root/'etc/os-release').is_file() or not (root/'usr').is_dir():parser.error('Choose an extracted ISO filesystem, not the running root')
files=[root/'etc/xdg/autostart/aos-live.desktop',root/'etc/skel/.config/autostart/welcome-live.desktop']
for directory in (root/'home').glob('*'):
 files.extend([directory/'.config/autostart/aos-live.desktop',directory/'.config/autostart/welcome-live.desktop'])
backup=root/'var/backups/dango-live-startup';backup.mkdir(parents=True,exist_ok=True)
for path in files:
 if not path.is_file():continue
 if not path.resolve().is_relative_to(root):raise ValueError('Entry escapes ISO root')
 text=path.read_text()
 if re.search(r'^Hidden=true\s*$',text,re.M):print('Already disabled:',path.relative_to(root));continue
 saved=backup/(str(path.relative_to(root)).replace('/','_')+'.'+str(time.time_ns()));shutil.copy2(path,saved)
 text=re.sub(r'^Hidden=.*\n?', '', text,flags=re.M);text=text.replace('[Desktop Entry]','[Desktop Entry]\nHidden=true',1);path.write_text(text)
 print('Disabled:',path.relative_to(root),'backup:',saved.relative_to(root))
