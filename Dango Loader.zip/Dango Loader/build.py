#!/usr/bin/python3
"""Build a root-owned Debian package without installing or running it."""
import hashlib,shutil,subprocess,tempfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='dango-build-') as directory:
 root=Path(directory);dest=root/'usr/share/dango-loader';dest.mkdir(parents=True)
 for name in ('dango','branding','translations'):shutil.copytree(BASE/name,dest/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for name in ('main.py','helper.py','launch-root.py','README.md','check.svg','world.geojson','WORLD-MAP-SOURCE.md','live-desktop.py','chevron.svg','dango-loader.svg','dango-loader.png'):shutil.copy2(BASE/name,dest/name)
 (dest/'helper.py').chmod(0o755);(dest/'launch-root.py').chmod(0o755)
 config=root/'etc/dango-loader';config.mkdir(parents=True);shutil.copy2(BASE/'installer.json',config/'installer.json')
 bin=root/'usr/bin';bin.mkdir(parents=True);(bin/'dango-loader').write_text('#!/bin/sh\nexec /usr/bin/python3 -I /usr/share/dango-loader/main.py "$@"\n');(bin/'dango-loader').chmod(0o755)
 # Isolated Python must explicitly include its installed, protected module directory.
 main=(dest/'main.py').read_text().replace('from dango.ui import Installer','sys.path.insert(0,str(Path(__file__).resolve().parent))\nfrom dango.ui import Installer');(dest/'main.py').write_text(main)
 app=root/'usr/share/applications';app.mkdir(parents=True);shutil.copy2(BASE/'packaging/dango-loader.desktop',app/'dango-loader.desktop')
 policy=root/'usr/share/polkit-1/actions';policy.mkdir(parents=True);shutil.copy2(BASE/'packaging/org.archiveos.dango-loader.policy',policy/'org.archiveos.dango-loader.policy')
 shutil.copy2(BASE/'packaging/org.archiveos.dango-loader.launch.policy',policy/'org.archiveos.dango-loader.launch.policy')
 icons=root/'usr/share/icons/hicolor/256x256/apps';icons.mkdir(parents=True);shutil.copy2(BASE/'dango-loader.png',icons/'dango-loader.png')
 autostart=root/'etc/xdg/autostart';autostart.mkdir(parents=True);shutil.copy2(BASE/'packaging/dango-loader-live.desktop',autostart/'dango-loader-live.desktop')
 control=root/'DEBIAN';control.mkdir();(control/'control').write_text("""Package: dango-loader
Version: 0.3.5
Architecture: all
Maintainer: ArchiveOS <archiveosofficial@gmail.com>
Depends: python3, python3-pyqt6, xkb-data, tzdata, pkexec, util-linux, fdisk, parted, ntfs-3g, squashfs-tools, e2fsprogs, btrfs-progs, xfsprogs, dosfstools, grub-pc-bin, grub-efi-amd64-bin, libkf6config-bin, locales, partitionmanager, fonts-noto-core, fonts-noto-cjk, openssl
Recommends: efibootmgr
Section: admin
Priority: optional
Description: Branded live ISO installer with a guided multilingual interface
 Initial Debian-family x86_64 UEFI/BIOS backend. Real installation is enabled
 for live ISO testing; target and source validation are still enforced.
""");(control/'conffiles').write_text('/etc/dango-loader/installer.json\n')
 for path in root.rglob('*'):
  if path.is_dir():path.chmod(0o755)
  elif not path.is_symlink() and path.name not in ('dango-loader','helper.py','launch-root.py'):path.chmod(0o644)
 md5=[]
 for path in sorted(root.rglob('*')):
  if path.is_file() and control not in path.parents:md5.append(hashlib.md5(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(root)))
 (control/'md5sums').write_text('\n'.join(md5)+'\n')
 output=BASE/'dango-loader_0.3.5_all.deb';subprocess.run(['dpkg-deb','--root-owner-group','--build',str(root),str(output)],check=True)
 (BASE/'SHA256SUMS').write_text(hashlib.sha256(output.read_bytes()).hexdigest()+'  '+output.name+'\n')
 print(output)
