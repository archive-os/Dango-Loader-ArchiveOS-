#!/usr/bin/python3
"""Install Dango in an extracted image; never install on the running host."""
import argparse,os,subprocess
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('root',type=Path);args=parser.parse_args()
root=args.root.resolve();base=Path(__file__).resolve().parent
if root==Path('/') or not (root/'etc/os-release').is_file() or not (root/'var/lib/dpkg/status').is_file():parser.error('Choose an extracted Debian-family ISO filesystem, not the running root')
if os.geteuid()!=0:parser.error('Run this integration script with sudo')
for relative in ('etc','usr','usr/share','usr/share/dango-loader','etc/dango-loader'):
 path=root/relative
 if path.is_symlink():raise RuntimeError('Unexpected image symlink: '+str(path))
subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=base,check=True)
subprocess.run(['dpkg','--root='+str(root),'--no-triggers','--force-confdef','--force-confold','--install',str(base/'dango-loader_0.3.5_all.deb')],check=True)
paths=[root,root/'etc',root/'usr',root/'usr/share',root/'usr/share/dango-loader',root/'etc/dango-loader']
for directory in (root/'usr/share/dango-loader',root/'etc/dango-loader'):
 paths.extend(directory.rglob('*'))
for path in paths:
 if path.is_symlink():raise RuntimeError('Unexpected symlink in privileged Dango paths: '+str(path))
 os.chown(path,0,0);os.chmod(path,path.stat().st_mode & 0o777 & ~0o022)
subprocess.run(['/usr/bin/python3',str(base/'fix-live-startup.py'),str(root)],check=True)
print('Dango installed in:',root)
