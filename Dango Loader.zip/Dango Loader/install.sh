#!/bin/sh
# Install into a Debian-family live ISO/chroot. Never starts a disk installation.
set -eu
DANGO_PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$DANGO_PROJECT_DIR"
sha256sum -c SHA256SUMS
if [ "$(id -u)" -ne 0 ]; then
    exec sudo /bin/sh "$DANGO_PROJECT_DIR/install.sh" "$@"
fi
apt-get install -y ./dango-loader_0.3.5_all.deb
printf '%s\n' 'Dango Loader installed. Run dango-loader --demo to preview.' 'Real installation is enabled in /etc/dango-loader/installer.json.'
